export type Platform = 'LinkedIn' | 'Twitter' | 'Instagram' | 'TikTok';

export interface GeneratedContent {
  platform: Platform;
  content: string;
  hashtags: string[];
  visualPrompt?: string; // For image generation suggestions
  stats?: {
    estimatedReach: string;
    viralityScore: number;
  };
}

export interface ContentPiece {
  id: string;
  title: string;
  originalText: string;
  createdAt: Date;
  transformations: GeneratedContent[];
}

export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  CREATE = 'CREATE',
  ANALYTICS = 'ANALYTICS',
  BRAND_VOICE = 'BRAND_VOICE',
}

export interface BrandVoiceAttribute {
  name: string;
  value: number; // 0-100
  description: string;
}

export interface ChartData {
  name: string;
  value: number;
}
