import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import ContentCreation from './components/ContentCreation';
import BrandVoice from './components/BrandVoice';
import { ViewState } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.DASHBOARD);

  const renderView = () => {
    switch (currentView) {
      case ViewState.DASHBOARD:
        return <Dashboard />;
      case ViewState.CREATE:
        return <ContentCreation />;
      case ViewState.ANALYTICS:
        return (
            <div className="h-full flex items-center justify-center">
                 <div className="text-center p-12 bg-white/40 backdrop-blur-xl rounded-3xl border border-white/60">
                    <h2 className="text-2xl font-serif text-stone-700 mb-2">Analytics Suite</h2>
                    <p className="text-stone-400">Coming in Phase 2. Detailed tracking for all generated assets.</p>
                 </div>
            </div>
        );
      case ViewState.BRAND_VOICE:
        return <BrandVoice />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-stone-100 to-stone-200 text-stone-800 font-sans selection:bg-amber-200 selection:text-amber-900">
      
      {/* Background Ambience - The "Aura" */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-stone-200/40 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-champagne-100/60 rounded-full blur-[120px]" />
        <div className="absolute top-[40%] left-[40%] w-[30%] h-[30%] bg-white/60 rounded-full blur-[100px]" />
      </div>

      <Navigation currentView={currentView} onNavigate={setCurrentView} />

      <main className="relative z-10 pl-32 pr-8 py-8 min-h-screen max-w-[1920px] mx-auto flex flex-col">
        {/* Header Area */}
        <header className="flex justify-between items-center mb-8 h-16">
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_10px_rgba(52,211,153,0.5)]"></div>
             <span className="text-xs font-medium text-stone-400 uppercase tracking-widest">OmniAura v1.0</span>
           </div>
           
           <div className="flex items-center gap-4">
              <div className="bg-white/50 backdrop-blur-md px-4 py-2 rounded-full border border-white/60 shadow-sm flex items-center gap-2">
                  <span className="text-sm text-stone-600">Credits</span>
                  <span className="text-sm font-bold text-stone-800">850</span>
              </div>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-stone-700 to-stone-900 text-white flex items-center justify-center font-serif italic border-2 border-white/20 shadow-lg">
                  OA
              </div>
           </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 relative">
            {renderView()}
        </div>
      </main>
    </div>
  );
}

export default App;
