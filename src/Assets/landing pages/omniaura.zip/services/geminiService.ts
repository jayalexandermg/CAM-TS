import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedContent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are OmniAura, an elite content transformation engine. 
Your goal is to take raw input text and repurpose it into high-performing social media content.
Maintain a sophisticated, engaging, and platform-native tone.
`;

export const transformContent = async (inputText: string): Promise<GeneratedContent[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Transform the following content into optimized posts for LinkedIn, Twitter, and Instagram.\n\nSOURCE CONTENT:\n${inputText}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              platform: { 
                type: Type.STRING, 
                enum: ["LinkedIn", "Twitter", "Instagram"] 
              },
              content: { 
                type: Type.STRING, 
                description: "The formatted post content. For Twitter, separate threads with double newlines." 
              },
              hashtags: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              visualPrompt: {
                type: Type.STRING,
                description: "A description of a visual asset to accompany this post."
              },
              stats: {
                type: Type.OBJECT,
                properties: {
                  estimatedReach: { type: Type.STRING },
                  viralityScore: { type: Type.NUMBER }
                }
              }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as GeneratedContent[];
    }
    return [];
  } catch (error) {
    console.error("Gemini Transformation Error:", error);
    // Fallback mock data in case of API failure or limit
    return [
      {
        platform: 'LinkedIn',
        content: "Error connecting to OmniAura Intelligence. Please check your API key.",
        hashtags: ['#Error', '#TryAgain'],
        stats: { estimatedReach: '0', viralityScore: 0 }
      }
    ];
  }
};

export const analyzeBrandVoice = async (sampleText: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: `Analyze the tone, style, and structure of this text in one short paragraph describing the 'Brand Voice'. Text: ${sampleText}`
        });
        return response.text || "Analysis complete.";
    } catch (e) {
        return "Could not analyze voice at this time.";
    }
}
