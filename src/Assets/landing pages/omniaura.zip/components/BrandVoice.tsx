import React, { useState } from 'react';
import { Sliders, Mic2, Save, Wand2 } from 'lucide-react';

const VoiceSlider = ({ label, leftLabel, rightLabel, value, onChange }: any) => (
  <div className="mb-8">
    <div className="flex justify-between mb-3 text-sm font-medium text-stone-500">
      <span>{leftLabel}</span>
      <span className="text-stone-800">{label}</span>
      <span>{rightLabel}</span>
    </div>
    <div className="relative h-12 bg-stone-100 rounded-2xl flex items-center px-4 cursor-pointer group hover:bg-stone-200/50 transition-colors">
        <input 
            type="range" 
            min="0" 
            max="100" 
            value={value} 
            onChange={(e) => onChange(parseInt(e.target.value))}
            className="absolute inset-0 w-full opacity-0 cursor-pointer z-10"
        />
        {/* Track */}
        <div className="w-full h-1 bg-stone-300 rounded-full overflow-hidden">
            <div className="h-full bg-stone-800 transition-all duration-300" style={{ width: `${value}%` }}></div>
        </div>
        {/* Thumb */}
        <div 
            className="absolute w-8 h-8 bg-white rounded-full shadow-lg border border-stone-100 flex items-center justify-center transition-all duration-300 pointer-events-none"
            style={{ left: `calc(${value}% - 16px)` }}
        >
            <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
        </div>
    </div>
  </div>
);

const BrandVoice: React.FC = () => {
  const [formality, setFormality] = useState(60);
  const [emotion, setEmotion] = useState(40);
  const [humor, setHumor] = useState(20);
  const [sampleText, setSampleText] = useState('');

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in duration-700 slide-in-from-bottom-4">
        <div className="text-center mb-12">
            <h1 className="text-4xl font-serif text-stone-800 mb-2">Brand Voice Profiler</h1>
            <p className="text-stone-500">Teach OmniAura to sound exactly like you.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white/40 backdrop-blur-xl border border-white/60 p-8 rounded-3xl shadow-sm">
                <div className="flex items-center gap-3 mb-8">
                    <Sliders className="w-5 h-5 text-stone-400" />
                    <h2 className="text-lg font-medium text-stone-700">Tone Adjusters</h2>
                </div>
                
                <VoiceSlider 
                    label="Formality" 
                    leftLabel="Casual" 
                    rightLabel="Professional" 
                    value={formality}
                    onChange={setFormality}
                />
                <VoiceSlider 
                    label="Emotion" 
                    leftLabel="Factual" 
                    rightLabel="Passionate" 
                    value={emotion}
                    onChange={setEmotion}
                />
                <VoiceSlider 
                    label="Humor" 
                    leftLabel="Serious" 
                    rightLabel="Witty" 
                    value={humor}
                    onChange={setHumor}
                />
            </div>

            <div className="space-y-6">
                <div className="bg-white/40 backdrop-blur-xl border border-white/60 p-8 rounded-3xl shadow-sm h-full flex flex-col">
                    <div className="flex items-center gap-3 mb-6">
                        <Mic2 className="w-5 h-5 text-stone-400" />
                        <h2 className="text-lg font-medium text-stone-700">Analyze My Voice</h2>
                    </div>
                    <textarea 
                        className="flex-1 w-full bg-white/50 border border-white/40 rounded-2xl p-4 text-stone-600 resize-none focus:outline-none focus:ring-1 focus:ring-stone-300 transition-all mb-4 text-sm leading-relaxed"
                        placeholder="Paste 3-4 examples of your best content here. We will analyze sentence structure, vocabulary, and cadence to build your profile."
                        value={sampleText}
                        onChange={(e) => setSampleText(e.target.value)}
                    />
                    <button className="w-full py-3 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-600 font-medium transition-colors flex items-center justify-center gap-2">
                        <Wand2 className="w-4 h-4" />
                        Analyze & Adapt
                    </button>
                </div>
            </div>
        </div>
        
        <div className="mt-8 flex justify-end">
            <button className="bg-stone-800 text-white px-8 py-3 rounded-xl flex items-center gap-2 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <Save className="w-4 h-4" />
                Save Profile
            </button>
        </div>
    </div>
  );
};

export default BrandVoice;
