import React, { useState } from 'react';
import { Sparkles, Linkedin, Twitter, Instagram, Copy, CheckCircle2, Loader2, Image as ImageIcon } from 'lucide-react';
import { transformContent } from '../services/geminiService';
import { GeneratedContent } from '../types';

const PlatformIcon = ({ platform }: { platform: string }) => {
  switch (platform) {
    case 'LinkedIn': return <Linkedin className="w-5 h-5" />;
    case 'Twitter': return <Twitter className="w-5 h-5" />;
    case 'Instagram': return <Instagram className="w-5 h-5" />;
    default: return <Sparkles className="w-5 h-5" />;
  }
};

const ContentCreation: React.FC = () => {
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [results, setResults] = useState<GeneratedContent[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setIsGenerating(true);
    const data = await transformContent(input);
    setResults(data);
    setIsGenerating(false);
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="h-full flex flex-col lg:flex-row gap-8 animate-in fade-in duration-700">
      
      {/* Input Section */}
      <div className="flex-1 flex flex-col h-full min-h-[500px]">
        <div className="bg-white/40 backdrop-blur-xl border border-white/60 rounded-3xl p-1 shadow-sm flex-1 flex flex-col relative overflow-hidden group">
          <textarea
            className="w-full h-full bg-transparent p-8 resize-none focus:outline-none text-lg text-stone-700 placeholder-stone-400 font-light leading-relaxed"
            placeholder="Paste your article, rough notes, or transcript here. OmniAura will handle the rest..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <div className="absolute bottom-6 right-6">
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !input.trim()}
              className="bg-stone-800 text-white pl-6 pr-8 py-4 rounded-2xl flex items-center gap-3 hover:bg-black transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-xl hover:shadow-2xl active:scale-95"
            >
              {isGenerating ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Sparkles className="w-5 h-5 text-amber-400" />
              )}
              <span className="font-medium tracking-wide">Generate Magic</span>
            </button>
          </div>
        </div>
        <div className="mt-4 flex gap-4 text-xs text-stone-400 px-4">
            <span>Supported: Text, Markdown</span>
            <span>•</span>
            <span>Max: 5000 chars</span>
        </div>
      </div>

      {/* Output Section */}
      <div className="flex-1 flex flex-col gap-6 overflow-y-auto pr-2 pb-20 custom-scroll">
        {results.length === 0 && !isGenerating ? (
            <div className="h-full flex flex-col items-center justify-center text-stone-300 border-2 border-dashed border-stone-200 rounded-3xl p-12">
                <Sparkles className="w-12 h-12 mb-4 opacity-50" />
                <p className="font-serif italic text-lg text-center">Your transformed content will appear here,<br/>ready for the world.</p>
            </div>
        ) : null}

        {isGenerating && (
            <div className="h-full flex items-center justify-center">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-1 bg-stone-200 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-400 animate-[loading_1.5s_ease-in-out_infinite]"></div>
                    </div>
                    <p className="text-stone-500 animate-pulse font-serif italic">Weaving the aura...</p>
                </div>
            </div>
        )}

        {results.map((result, idx) => (
          <div 
            key={idx} 
            className="bg-white/60 backdrop-blur-md border border-white/80 rounded-3xl p-6 shadow-sm hover:shadow-aura transition-all duration-500 group animate-in slide-in-from-bottom-8 fill-mode-backwards"
            style={{ animationDelay: `${idx * 150}ms` }}
          >
            <div className="flex justify-between items-center mb-4 border-b border-stone-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-xl shadow-sm text-stone-700">
                    <PlatformIcon platform={result.platform} />
                </div>
                <span className="font-medium text-stone-800">{result.platform}</span>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => copyToClipboard(result.content, idx)}
                  className="p-2 hover:bg-stone-100 rounded-xl transition-colors text-stone-500"
                  title="Copy Content"
                >
                  {copiedIndex === idx ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="prose prose-stone prose-sm max-w-none mb-6">
              <p className="whitespace-pre-wrap text-stone-600 leading-relaxed">{result.content}</p>
            </div>

            {result.hashtags && (
              <div className="flex flex-wrap gap-2 mb-6">
                {result.hashtags.map((tag, i) => (
                  <span key={i} className="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-md">
                    {tag}
                  </span>
                ))}
              </div>
            )}

            {result.visualPrompt && (
                <div className="bg-stone-100/50 rounded-xl p-4 flex items-start gap-3 border border-stone-100">
                    <ImageIcon className="w-4 h-4 text-stone-400 mt-1 shrink-0" />
                    <div>
                        <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Visual Suggestion</p>
                        <p className="text-sm text-stone-600 italic">{result.visualPrompt}</p>
                    </div>
                </div>
            )}

            {result.stats && (
                <div className="mt-4 flex gap-6 pt-4 border-t border-stone-100">
                    <div>
                        <p className="text-xs text-stone-400">Est. Reach</p>
                        <p className="font-medium text-stone-700">{result.stats.estimatedReach}</p>
                    </div>
                    <div>
                        <p className="text-xs text-stone-400">Virality</p>
                        <div className="flex items-center gap-1">
                             <div className="h-1.5 w-16 bg-stone-200 rounded-full overflow-hidden">
                                <div className="h-full bg-emerald-400" style={{ width: `${result.stats.viralityScore * 10}%`}}></div>
                             </div>
                             <span className="text-xs text-stone-600">{result.stats.viralityScore}/10</span>
                        </div>
                    </div>
                </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContentCreation;
