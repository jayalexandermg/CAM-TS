import React from 'react';
import { LayoutGrid, PenTool, BarChart3, Settings, Sparkles, LogOut } from 'lucide-react';
import { ViewState } from '../types';

interface NavigationProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onNavigate }) => {
  const navItems = [
    { id: ViewState.DASHBOARD, icon: LayoutGrid, label: 'Overview' },
    { id: ViewState.CREATE, icon: PenTool, label: 'Create' },
    { id: ViewState.ANALYTICS, icon: BarChart3, label: 'Analytics' },
    { id: ViewState.BRAND_VOICE, icon: Settings, label: 'Brand Voice' },
  ];

  return (
    <nav className="fixed left-6 top-1/2 -translate-y-1/2 z-50">
      <div className="bg-white/40 backdrop-blur-2xl border border-white/50 p-4 rounded-3xl shadow-aura flex flex-col items-center gap-8 w-20 transition-all duration-500 hover:w-24 group">
        
        <div className="mb-4 text-stone-800">
           <Sparkles className="w-8 h-8 text-amber-500 fill-amber-500/20" />
        </div>

        <div className="flex flex-col gap-6 w-full">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`relative flex items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 group/btn
                  ${isActive 
                    ? 'bg-stone-800 text-white shadow-lg' 
                    : 'text-stone-500 hover:bg-white/60 hover:text-stone-800'
                  }`}
              >
                <item.icon className="w-5 h-5" />
                {isActive && (
                    <div className="absolute left-14 bg-stone-800 text-white text-xs px-2 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                        {item.label}
                    </div>
                )}
              </button>
            );
          })}
        </div>

        <div className="mt-auto pt-8 border-t border-stone-200 w-full flex justify-center">
            <button className="text-stone-400 hover:text-red-400 transition-colors">
                <LogOut className="w-5 h-5" />
            </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
