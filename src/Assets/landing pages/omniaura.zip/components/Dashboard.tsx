import React from 'react';
import { ArrowUpRight, Activity, Users, Zap } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Mon', value: 400 },
  { name: 'Tue', value: 300 },
  { name: 'Wed', value: 600 },
  { name: 'Thu', value: 800 },
  { name: 'Fri', value: 500 },
  { name: 'Sat', value: 900 },
  { name: 'Sun', value: 750 },
];

const StatCard = ({ title, value, change, icon: Icon }: any) => (
  <div className="bg-white/40 backdrop-blur-xl border border-white/60 p-6 rounded-3xl shadow-sm hover:shadow-aura transition-all duration-500">
    <div className="flex justify-between items-start mb-4">
      <div className="p-3 bg-stone-100 rounded-2xl text-stone-600">
        <Icon className="w-6 h-6" />
      </div>
      <span className="flex items-center text-sm font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
        +{change}% <ArrowUpRight className="w-3 h-3 ml-1" />
      </span>
    </div>
    <h3 className="text-stone-500 text-sm font-medium mb-1">{title}</h3>
    <p className="text-3xl font-serif text-stone-800">{value}</p>
  </div>
);

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-700 slide-in-from-bottom-4">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-serif text-stone-800 mb-2">Good afternoon, Creator.</h1>
          <p className="text-stone-500">Your omni-channel presence is growing.</p>
        </div>
        <div className="text-right hidden md:block">
            <p className="text-xs text-stone-400 uppercase tracking-widest">Next Scheduled Post</p>
            <p className="text-stone-700 font-medium mt-1">Tomorrow, 10:00 AM • LinkedIn</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Total Reach" value="128.4k" change="12" icon={Users} />
        <StatCard title="Engagement Rate" value="4.8%" change="0.8" icon={Activity} />
        <StatCard title="AI Credits" value="850" change="100" icon={Zap} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-96">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white/40 backdrop-blur-xl border border-white/60 p-8 rounded-3xl shadow-sm">
          <h3 className="text-lg font-medium text-stone-800 mb-6">Audience Growth</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d9ad3d" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#d9ad3d" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#a8a29e'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#a8a29e'}} />
                <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}
                />
                <Area type="monotone" dataKey="value" stroke="#d9ad3d" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white/40 backdrop-blur-xl border border-white/60 p-8 rounded-3xl shadow-sm overflow-hidden relative">
             <h3 className="text-lg font-medium text-stone-800 mb-6">Recent Magic</h3>
             <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4 p-3 hover:bg-white/50 rounded-xl transition-colors cursor-pointer">
                        <div className="w-10 h-10 rounded-full bg-stone-200 flex items-center justify-center text-xs font-bold text-stone-500">
                            {i === 1 ? 'LI' : i === 2 ? 'IG' : 'TW'}
                        </div>
                        <div>
                            <p className="text-sm font-medium text-stone-800">Product Launch Strategy</p>
                            <p className="text-xs text-stone-500">2 hours ago</p>
                        </div>
                    </div>
                ))}
             </div>
             {/* Decorative blur */}
             <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-amber-200/20 rounded-full blur-3xl pointer-events-none"></div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
