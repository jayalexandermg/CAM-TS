# GenieForge Starter Repo

1. Copy `.env.example` to `.env.local`
2. Run `pnpm install && pnpm dev`
