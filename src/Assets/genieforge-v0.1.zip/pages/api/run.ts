// API route for invoking planner + coder agents
