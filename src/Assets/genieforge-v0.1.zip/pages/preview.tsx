// Renders generated React code using Sandpack
