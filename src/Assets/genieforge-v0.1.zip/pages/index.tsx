// Entry point UI: Spec input + buttons
