// Agent to break spec into plan and tasks
