
import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available from environment variables
if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const systemInstruction = `You are an expert UI/UX and web design consultant. 
Your role is to analyze a user-provided screenshot and their accompanying notes. 
The user's notes describe their goal or concern regarding the interface in the screenshot.

Your task is to provide constructive, actionable feedback. Follow these steps:
1.  **Acknowledge the Goal:** Briefly restate the user's goal to show you understand.
2.  **Analyze the Screenshot:** Based on the user's goal, analyze the relevant elements in the image. Point out strengths and weaknesses.
3.  **Provide Actionable Suggestions:** Offer 3-5 clear, concrete suggestions for improvement. Use bullet points or a numbered list. Explain *why* each suggestion would help achieve the user's goal.
4.  **Maintain a Helpful Tone:** Be encouraging and professional. Frame your feedback as helpful advice, not criticism.

Format your response using Markdown for clarity.`;

export const getAiFeedback = async (screenshotBase64: string, annotation: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { text: annotation },
          {
            inlineData: {
              mimeType: 'image/png',
              data: screenshotBase64,
            },
          },
        ],
      },
      config: {
        systemInstruction: systemInstruction,
      }
    });
    
    return response.text;

  } catch (error) {
    console.error("Gemini API call failed:", error);
    throw new Error("Failed to get feedback from the AI model.");
  }
};
