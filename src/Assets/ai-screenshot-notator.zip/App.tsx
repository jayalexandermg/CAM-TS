import React, { useState, useCallback } from 'react';
import WelcomeScreen from './components/WelcomeScreen';
import ScreenshotView from './components/ScreenshotView';
import { getAiFeedback } from './services/geminiService';

const App: React.FC = () => {
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [annotation, setAnnotation] = useState<string>('');
  const [aiResponse, setAiResponse] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleScreenshot = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setScreenshot(null);
    setAnnotation('');
    setAiResponse('');

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        // Fix: Cast video constraints to 'any' to allow the 'cursor' property,
        // which is valid for getDisplayMedia but may be missing from TS DOM types.
        video: { cursor: "always" } as any,
        audio: false,
      });

      const video = document.createElement('video');
      video.srcObject = stream;
      video.play();

      video.onloadedmetadata = () => {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/png');
          setScreenshot(dataUrl);
        } else {
            setError('Could not get canvas context.');
        }
        stream.getTracks().forEach(track => track.stop());
        setIsLoading(false);
      };
    } catch (err) {
      console.error("Error capturing screen: ", err);
      setError("Failed to capture screen. Please grant permission and try again.");
      setIsLoading(false);
    }
  }, []);

  const handleReset = useCallback(() => {
    setScreenshot(null);
    setAnnotation('');
    setAiResponse('');
    setError(null);
    setIsLoading(false);
  }, []);

  const handleGetFeedback = useCallback(async () => {
    if (!screenshot || !annotation) return;

    setIsLoading(true);
    setError(null);
    setAiResponse('');

    try {
      // The Gemini API needs the pure base64 data, without the data URL prefix.
      const base64Data = screenshot.split(',')[1];
      const response = await getAiFeedback(base64Data, annotation);
      setAiResponse(response);
    } catch (err) {
      console.error("Error getting AI feedback: ", err);
      setError("An error occurred while getting AI feedback. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [screenshot, annotation]);

  return (
    <div className="bg-gray-900 text-white min-h-screen w-full flex flex-col items-center justify-center p-4 selection:bg-indigo-500 selection:text-white">
      {screenshot ? (
        <ScreenshotView
          screenshot={screenshot}
          annotation={annotation}
          setAnnotation={setAnnotation}
          aiResponse={aiResponse}
          isLoading={isLoading}
          error={error}
          onGetFeedback={handleGetFeedback}
          onReset={handleReset}
        />
      ) : (
        <WelcomeScreen onScreenshot={handleScreenshot} isLoading={isLoading} error={error} />
      )}
    </div>
  );
};

export default App;
