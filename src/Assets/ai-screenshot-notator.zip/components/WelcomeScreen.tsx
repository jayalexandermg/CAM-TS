
import React from 'react';
import { CameraIcon } from './icons/CameraIcon';
import LoadingSpinner from './LoadingSpinner';

interface WelcomeScreenProps {
  onScreenshot: () => void;
  isLoading: boolean;
  error: string | null;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onScreenshot, isLoading, error }) => {
  return (
    <div className="text-center flex flex-col items-center max-w-2xl mx-auto p-8">
      <div className="mb-6">
        <div className="w-24 h-24 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-indigo-500/30">
           <CameraIcon className="w-12 h-12 text-indigo-400" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">
          AI Screenshot Notator
        </h1>
        <p className="mt-4 text-lg text-gray-400">
          Capture any part of your screen, add your thoughts or goals, and let our AI provide you with expert UI/UX feedback and optimization suggestions instantly.
        </p>
      </div>

      <button
        onClick={onScreenshot}
        disabled={isLoading}
        className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white bg-indigo-600 rounded-full shadow-lg overflow-hidden transition-all duration-300 ease-in-out hover:scale-105 hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-500 focus:ring-opacity-50 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:scale-100"
      >
        {isLoading ? (
          <>
            <LoadingSpinner />
            <span className="ml-3">Capturing...</span>
          </>
        ) : (
          <>
            <CameraIcon className="w-6 h-6 mr-3 transition-transform duration-300 group-hover:rotate-12" />
            Take Screenshot
          </>
        )}
      </button>

      {error && (
        <div className="mt-6 p-4 bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg">
          <p>{error}</p>
        </div>
      )}
    </div>
  );
};

export default WelcomeScreen;
