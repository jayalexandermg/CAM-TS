
import React from 'react';
import LoadingSpinner from './LoadingSpinner';
import { SparklesIcon } from './icons/SparklesIcon';
import { RestartIcon } from './icons/RestartIcon';

interface ScreenshotViewProps {
  screenshot: string;
  annotation: string;
  setAnnotation: (value: string) => void;
  aiResponse: string;
  isLoading: boolean;
  error: string | null;
  onGetFeedback: () => void;
  onReset: () => void;
}

const ScreenshotView: React.FC<ScreenshotViewProps> = ({
  screenshot,
  annotation,
  setAnnotation,
  aiResponse,
  isLoading,
  error,
  onGetFeedback,
  onReset,
}) => {
  return (
    <div className="w-full max-w-7xl mx-auto p-4 md:p-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        
        {/* Left Column: Screenshot */}
        <div className="flex flex-col gap-4">
           <h2 className="text-xl font-semibold text-gray-300">Your Screenshot</h2>
          <div className="bg-gray-800 p-2 rounded-lg shadow-2xl border border-gray-700">
             <img src={screenshot} alt="User screenshot" className="w-full h-auto rounded-md" />
          </div>
        </div>
        
        {/* Right Column: Annotation & AI Feedback */}
        <div className="flex flex-col gap-6">

          {/* Annotation Input */}
          <div className="flex flex-col gap-4">
            <label htmlFor="annotation" className="text-xl font-semibold text-gray-300">
              Why did you take this screenshot?
            </label>
            <textarea
              id="annotation"
              value={annotation}
              onChange={(e) => setAnnotation(e.target.value)}
              placeholder="e.g., 'I want to improve the call-to-action button.' or 'Does this form look too complicated?'"
              className="w-full h-32 p-4 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200 resize-none text-gray-200 placeholder-gray-500"
              disabled={isLoading}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={onGetFeedback}
              disabled={isLoading || !annotation.trim()}
              className="flex-1 inline-flex items-center justify-center px-6 py-3 text-base font-bold text-white bg-indigo-600 rounded-lg shadow-md transition-all duration-300 ease-in-out hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-500 focus:ring-opacity-50 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:text-gray-400"
            >
              {isLoading && !aiResponse ? (
                <>
                  <LoadingSpinner />
                  <span className="ml-3">Analyzing...</span>
                </>
              ) : (
                <>
                  <SparklesIcon className="w-5 h-5 mr-3" />
                  Get AI Feedback
                </>
              )}
            </button>
             <button
              onClick={onReset}
              className="flex-1 inline-flex items-center justify-center px-6 py-3 text-base font-bold text-gray-300 bg-gray-700 rounded-lg shadow-md transition-all duration-300 ease-in-out hover:bg-gray-600 focus:outline-none focus:ring-4 focus:ring-gray-600 focus:ring-opacity-50"
            >
               <RestartIcon className="w-5 h-5 mr-3" />
              Take Another Screenshot
            </button>
          </div>
          
          {/* AI Response Area */}
          <div className="flex flex-col gap-4">
             <h2 className="text-xl font-semibold text-gray-300">AI Suggestions</h2>
             <div className="w-full min-h-[200px] p-4 bg-gray-800 border border-gray-700 rounded-lg">
                {isLoading && !aiResponse && (
                   <div className="flex items-center justify-center h-full text-gray-400">
                      <LoadingSpinner />
                      <span className="ml-3">AI is thinking...</span>
                   </div>
                )}
                {error && <div className="text-red-400">{error}</div>}
                {aiResponse && (
                  <div className="prose prose-invert prose-p:text-gray-300 prose-headings:text-gray-100 prose-strong:text-white prose-ul:text-gray-300 whitespace-pre-wrap font-sans text-gray-300">{aiResponse}</div>
                )}
                 {!isLoading && !error && !aiResponse && <p className="text-gray-500">AI feedback will appear here.</p>}
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default ScreenshotView;
