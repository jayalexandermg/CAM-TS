import { GoogleGenAI, Type } from "@google/genai";
import { ProjectInfo, GeneratedPlan, Role, TeamMember, Assignment } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = "gemini-3-flash-preview";

export const generateRoleMap = async (project: ProjectInfo): Promise<GeneratedPlan> => {
  const prompt = `
    Create a comprehensive role and task map for a project named "${project.name}".
    Description: "${project.description}".
    The team size is ${project.teamSize}.
    
    Generate 4 to 6 distinct functional roles required to bring this specific idea to market.
    For each role, list exactly 3 critical, actionable tasks/responsibilities.
    The tasks should be specific to the project description, not generic.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          roles: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                tasks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      role: { type: Type.STRING },
                      title: { type: Type.STRING },
                      description: { type: Type.STRING }
                    },
                    required: ["title", "description"]
                  }
                }
              },
              required: ["title", "description", "tasks"]
            }
          }
        }
      }
    }
  });

  if (response.text) {
    const data = JSON.parse(response.text) as GeneratedPlan;
    // Post-process to ensure IDs exist
    data.roles.forEach(role => {
      role.tasks.forEach(task => {
        if (!task.id) task.id = Math.random().toString(36).substr(2, 9);
        if (!task.role) task.role = role.title;
      });
    });
    return data;
  }

  throw new Error("Failed to generate plan");
};

export const suggestAssignments = async (
  project: ProjectInfo, 
  roles: Role[], 
  members: TeamMember[]
): Promise<Assignment[]> => {
  
  // Flatten tasks for context
  const allTasks = roles.flatMap(r => r.tasks.map(t => ({ id: t.id, title: t.title, role: r.title })));
  
  const prompt = `
    I have a team of ${members.length} people (IDs: ${members.map(m => m.id).join(', ')}).
    Project: ${project.name} - ${project.description}.
    
    Here are the tasks that need ownership:
    ${JSON.stringify(allTasks)}

    Act as an expert project manager. Assign ownership ('own') and support ('support') roles to these team members to ensure:
    1. Every task has exactly one owner.
    2. Workload is balanced.
    3. Complex tasks have at least one supporter.
    
    Return a JSON array of assignments.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          assignments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                taskId: { type: Type.STRING },
                memberId: { type: Type.STRING },
                type: { type: Type.STRING, enum: ["own", "support", "avoid"] }
              },
              required: ["taskId", "memberId", "type"]
            }
          }
        }
      }
    }
  });

  if (response.text) {
    const data = JSON.parse(response.text) as { assignments: Assignment[] };
    return data.assignments;
  }
  
  return [];
};