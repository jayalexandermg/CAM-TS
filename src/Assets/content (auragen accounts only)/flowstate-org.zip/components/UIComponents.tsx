import React from 'react';

// --- Styles & Constants ---

// Clay/Glass Hybrid Styles
// We use high blur, translucent borders, and multiple shadows to create depth
const GLASS_PANEL_CLASSES = "bg-white/5 backdrop-blur-2xl border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.36)]";
const CLAY_SURFACE_CLASSES = "shadow-[inset_-2px_-2px_6px_rgba(255,255,255,0.05),inset_2px_2px_6px_rgba(0,0,0,0.6)]";
const HOVER_LIFT_CLASSES = "transition-all duration-300 ease-out hover:-translate-y-1 hover:shadow-[0_20px_40px_-12px_rgba(0,0,0,0.5)]";

interface ClayButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'magic';
  children: React.ReactNode;
}

export const ClayButton: React.FC<ClayButtonProps> = ({ variant = 'primary', className = '', children, ...props }) => {
  const baseStyle = "relative rounded-2xl font-bold tracking-wide transition-all duration-300 flex items-center justify-center outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0f172a] focus:ring-cyan-500/50 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden group";
  
  const variants = {
    primary: "bg-gradient-to-br from-cyan-400 via-cyan-500 to-blue-600 text-white shadow-[0_10px_20px_-5px_rgba(6,182,212,0.4)] hover:shadow-[0_20px_30px_-10px_rgba(6,182,212,0.5)] border-t border-white/20 px-8 py-4 text-lg",
    
    magic: "bg-gradient-to-br from-fuchsia-500 via-purple-600 to-indigo-600 text-white shadow-[0_10px_20px_-5px_rgba(192,38,211,0.4)] hover:shadow-[0_20px_30px_-10px_rgba(192,38,211,0.5)] border-t border-white/20 px-6 py-3",

    secondary: `bg-[#1e293b] text-cyan-100 ${CLAY_SURFACE_CLASSES} border border-white/5 hover:bg-[#253248] hover:border-cyan-500/30 px-6 py-3`,
    
    danger: "bg-gradient-to-br from-rose-500 to-red-700 text-white shadow-[0_10px_20px_-5px_rgba(244,63,94,0.4)] border-t border-white/20 px-6 py-3",
    
    ghost: "bg-transparent text-cyan-200/70 hover:text-cyan-100 hover:bg-white/5 px-4 py-2"
  };

  return (
    <button className={`${baseStyle} ${variants[variant]} ${className}`} {...props}>
      {/* Shine effect on hover */}
      <div className="absolute inset-0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
      <span className="relative z-10 flex items-center gap-2">{children}</span>
    </button>
  );
};

export const GlassCard: React.FC<{ 
  children: React.ReactNode; 
  className?: string; 
  delay?: string;
  variant?: 'default' | 'solid';
}> = ({ children, className = '', delay = '0s', variant = 'default' }) => {
  const bgClass = variant === 'solid' ? 'bg-[#0f172a]/80' : 'bg-white/5';
  return (
    <div 
      className={`
        ${bgClass} backdrop-blur-2xl 
        border border-white/10 
        rounded-[2rem] p-8 
        shadow-[0_0_0_1px_rgba(255,255,255,0.05),0_20px_50px_rgba(0,0,0,0.5)]
        animate-fade-in-up
        ${className}
      `}
      style={{ animationDelay: delay }}
    >
      {children}
    </div>
  );
};

export const FloatingOrbs = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0 bg-[#0f172a]">
      {/* Deep Background Gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,#1e1b4b,transparent_80%)] opacity-60" />
      
      {/* Animated Orbs */}
      <div className="liquid-orb top-[-10%] left-[-10%] w-[600px] h-[600px] bg-cyan-600/20 mix-blend-screen animate-float blur-[100px]" />
      <div className="liquid-orb bottom-[-20%] right-[-10%] w-[700px] h-[700px] bg-purple-600/20 mix-blend-screen animate-float-delay blur-[120px]" />
      <div className="liquid-orb top-[30%] right-[20%] w-[400px] h-[400px] bg-blue-500/10 mix-blend-screen animate-float blur-[80px]" style={{ animationDuration: '12s' }} />
      
      {/* Noise Texture for realism */}
      <div className="absolute inset-0 opacity-[0.03] mix-blend-overlay" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }}></div>
    </div>
  );
};

export const ClayInput: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => {
  return (
    <div className="relative group">
      <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl opacity-0 group-hover:opacity-30 group-focus-within:opacity-100 transition duration-500 blur"></div>
      <input 
        {...props}
        className={`relative w-full bg-[#162032] text-cyan-50 placeholder-cyan-200/30 rounded-2xl px-6 py-5 outline-none border border-white/10 ${CLAY_SURFACE_CLASSES} focus:text-white transition-all ${props.className}`} 
      />
    </div>
  );
};

export const ClayTextArea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => {
  return (
     <div className="relative group">
      <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl opacity-0 group-hover:opacity-30 group-focus-within:opacity-100 transition duration-500 blur"></div>
      <textarea 
        {...props}
        className={`relative w-full bg-[#162032] text-cyan-50 placeholder-cyan-200/30 rounded-2xl px-6 py-5 outline-none border border-white/10 ${CLAY_SURFACE_CLASSES} focus:text-white transition-all ${props.className}`} 
      />
    </div>
  );
};

export const StatusBadge: React.FC<{ type: 'healthy' | 'warning' | 'critical' | 'neutral'; children: React.ReactNode }> = ({ type, children }) => {
  const styles = {
    healthy: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    warning: "bg-orange-500/10 text-orange-400 border-orange-500/20",
    critical: "bg-rose-500/10 text-rose-400 border-rose-500/20",
    neutral: "bg-slate-500/10 text-slate-400 border-slate-500/20"
  };
  
  return (
    <span className={`px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-bold border ${styles[type]}`}>
      {children}
    </span>
  );
};
