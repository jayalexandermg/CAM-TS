import React, { useState, useMemo } from 'react';
import { ProjectInfo, Role, TeamMember, Assignment } from './types';
import { generateRoleMap, suggestAssignments } from './services/geminiService';
import { ClayButton, GlassCard, ClayInput, ClayTextArea, FloatingOrbs, StatusBadge } from './components/UIComponents';
import { Loader2, User, CheckCircle2, AlertCircle, XCircle, ArrowRight, LayoutDashboard, FileText, Share2, Sparkles, Users, Layers, Zap } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';

// --- Sub-components ---

// 1. Initial Input Screen (Setup)
const ProjectSetup: React.FC<{ onComplete: (info: ProjectInfo) => void, isLoading: boolean }> = ({ onComplete, isLoading }) => {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [size, setSize] = useState(2);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && desc) onComplete({ name, description: desc, teamSize: size });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative z-10">
      <GlassCard className="max-w-2xl w-full animate-float">
        <div className="text-center mb-10">
          <div className="inline-block p-3 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 mb-4 shadow-[0_0_30px_-5px_rgba(6,182,212,0.3)]">
            <Layers className="text-cyan-400 w-10 h-10" />
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold bg-gradient-to-br from-white via-cyan-100 to-cyan-400 bg-clip-text text-transparent mb-3 tracking-tight">
            FlowState Org
          </h1>
          <p className="text-cyan-200/60 font-medium text-lg max-w-md mx-auto">
            Orchestrate your team with liquid precision. AI-powered alignment for future-ready squads.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-3">
            <label className="text-sm font-bold text-cyan-200/80 ml-2 uppercase tracking-widest text-[10px]">Project Identity</label>
            <ClayInput 
              placeholder="Project Name (e.g. Nebula Nexus)" 
              value={name} 
              onChange={e => setName(e.target.value)} 
              autoFocus
            />
          </div>
          
          <div className="space-y-3">
            <label className="text-sm font-bold text-cyan-200/80 ml-2 uppercase tracking-widest text-[10px]">Core Mission</label>
            <ClayTextArea 
              rows={3} 
              placeholder="What are you building? Who is it for?" 
              value={desc} 
              onChange={e => setDesc(e.target.value)} 
            />
          </div>

          <div className="space-y-3">
            <label className="text-sm font-bold text-cyan-200/80 ml-2 uppercase tracking-widest text-[10px]">Squad Size</label>
            <div className="bg-[#162032] rounded-2xl p-6 border border-white/10 flex items-center gap-6 shadow-inner">
              <Users className="text-cyan-500/50" size={24} />
              <input 
                type="range" 
                min="1" 
                max="10" 
                value={size} 
                onChange={e => setSize(Number(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 hover:accent-cyan-400 transition-all"
              />
              <div className="w-16 h-16 rounded-2xl bg-[#0f172a] flex items-center justify-center border border-white/10 shadow-lg">
                <span className="font-bold text-3xl text-cyan-400">{size}</span>
              </div>
            </div>
          </div>

          <div className="pt-6">
            <ClayButton type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <span className="flex items-center gap-3">
                  <Loader2 className="animate-spin" /> Neural Architecture Generating...
                </span>
              ) : (
                <span className="flex items-center gap-3">
                  Initialize Flow State <ArrowRight size={20} />
                </span>
              )}
            </ClayButton>
          </div>
        </form>
      </GlassCard>
    </div>
  );
};

// 2. Claiming Board (Claiming)
const TaskClaimBoard: React.FC<{ 
  project: ProjectInfo, 
  roles: Role[], 
  members: TeamMember[],
  assignments: Assignment[],
  onAssign: (taskId: string, memberId: string, type: Assignment['type']) => void,
  onAutoAssign: () => void,
  onFinish: () => void,
  isAutoAssigning: boolean
}> = ({ project, roles, members, assignments, onAssign, onAutoAssign, onFinish, isAutoAssigning }) => {
  const [activeMemberId, setActiveMemberId] = useState(members[0].id);

  // Helper to check status
  const getAssignment = (taskId: string, memberId: string) => {
    return assignments.find(a => a.taskId === taskId && a.memberId === memberId)?.type || null;
  };

  const getTaskStatus = (taskId: string) => {
    const taskAssigns = assignments.filter(a => a.taskId === taskId);
    const owners = taskAssigns.filter(a => a.type === 'own');
    if (owners.length === 0) return 'gap';
    if (owners.length > 1) return 'conflict';
    return 'covered';
  };

  return (
    <div className="min-h-screen p-6 pb-32 z-10 relative flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#0f172a]/80 backdrop-blur-xl -mx-6 px-6 py-4 border-b border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            {project.name} 
            <span className="px-2 py-1 bg-white/5 rounded-lg text-xs font-normal text-cyan-200/50 border border-white/5">Role Negotiation</span>
          </h2>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-[#162032] p-1.5 rounded-full border border-white/10 shadow-lg overflow-x-auto max-w-[50vw]">
            <span className="text-[10px] text-cyan-200/40 uppercase tracking-widest pl-3 font-bold hidden sm:block">You are:</span>
            {members.map(m => (
              <button
                key={m.id}
                onClick={() => setActiveMemberId(m.id)}
                className={`
                  relative w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 font-bold text-sm
                  ${activeMemberId === m.id 
                    ? 'bg-gradient-to-br from-cyan-400 to-blue-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.6)] scale-110 z-10 ring-2 ring-[#0f172a]' 
                    : 'bg-[#1e293b] text-cyan-200/50 hover:bg-[#253248] hover:text-cyan-200'}
                `}
              >
                {m.name.charAt(0)}
                {/* Active Indicator */}
                {activeMemberId === m.id && (
                    <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                    </span>
                )}
              </button>
            ))}
          </div>
          
          <ClayButton variant="magic" onClick={onAutoAssign} disabled={isAutoAssigning} className="hidden md:flex">
             {isAutoAssigning ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
             <span className="ml-2 text-sm">AI Distribute</span>
          </ClayButton>
        </div>
      </div>

      {/* Role Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {roles.map((role, rIdx) => (
          <GlassCard key={rIdx} className="!p-0 overflow-hidden flex flex-col !bg-white/[0.02]" delay={`${rIdx * 0.1}s`}>
            <div className="p-6 border-b border-white/10 bg-gradient-to-r from-white/[0.03] to-transparent">
              <h3 className="text-xl font-bold text-cyan-50">{role.title}</h3>
              <p className="text-cyan-200/40 text-xs mt-1 leading-relaxed">{role.description}</p>
            </div>
            
            <div className="p-4 space-y-3 flex-grow">
              {role.tasks.map((task) => {
                const myStatus = getAssignment(task.id, activeMemberId);
                const globalStatus = getTaskStatus(task.id);
                
                return (
                  <div key={task.id} className={`
                    relative bg-[#0f172a]/60 rounded-xl p-4 transition-all duration-300 border
                    ${globalStatus === 'gap' ? 'border-rose-500/20 shadow-[inset_0_0_20px_rgba(244,63,94,0.05)]' : 
                      globalStatus === 'conflict' ? 'border-orange-500/30 shadow-[inset_0_0_20px_rgba(249,115,22,0.05)]' : 
                      'border-white/5 hover:border-cyan-500/20'}
                  `}>
                    
                    {/* Status Indicator Dot */}
                    <div className={`absolute top-4 right-4 w-2 h-2 rounded-full ${globalStatus === 'gap' ? 'bg-rose-500 animate-pulse' : globalStatus === 'conflict' ? 'bg-orange-500' : 'bg-emerald-500/50'}`} />

                    <div className="mb-4 pr-6">
                      <h4 className="font-semibold text-cyan-50 text-sm">{task.title}</h4>
                      <p className="text-xs text-cyan-200/40 mt-1">{task.description}</p>
                    </div>

                    {/* Action Toggles */}
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => onAssign(task.id, activeMemberId, myStatus === 'own' ? null : 'own')}
                        className={`
                          py-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center justify-center gap-1
                          ${myStatus === 'own' 
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)]' 
                            : 'bg-white/5 text-gray-500 hover:bg-white/10 hover:text-gray-300'}
                        `}
                      >
                        <CheckCircle2 size={16} /> Own
                      </button>
                      
                      <button
                        onClick={() => onAssign(task.id, activeMemberId, myStatus === 'support' ? null : 'support')}
                        className={`
                          py-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center justify-center gap-1
                          ${myStatus === 'support' 
                            ? 'bg-blue-500/20 text-blue-400 border border-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.2)]' 
                            : 'bg-white/5 text-gray-500 hover:bg-white/10 hover:text-gray-300'}
                        `}
                      >
                        <User size={16} /> Support
                      </button>

                      <button
                         onClick={() => onAssign(task.id, activeMemberId, myStatus === 'avoid' ? null : 'avoid')}
                         className={`
                          py-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center justify-center gap-1
                          ${myStatus === 'avoid' 
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/50 shadow-[0_0_15px_rgba(244,63,94,0.2)]' 
                            : 'bg-white/5 text-gray-500 hover:bg-white/10 hover:text-gray-300'}
                        `}
                      >
                        <XCircle size={16} /> Pass
                      </button>
                    </div>

                    {/* Team avatars for this task */}
                    <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between">
                        <span className="text-[10px] text-cyan-200/30 uppercase font-bold">Assigned</span>
                        <div className="flex -space-x-1.5">
                        {members.filter(m => assignments.some(a => a.taskId === task.id && a.memberId === m.id)).length === 0 && (
                            <span className="text-[10px] text-rose-400/60 italic">Unclaimed</span>
                        )}
                        {members.map(m => {
                            const s = getAssignment(task.id, m.id);
                            if (!s) return null;
                            const colors = { own: 'bg-emerald-500', support: 'bg-blue-500', avoid: 'bg-rose-500' };
                            return (
                            <div 
                                key={m.id}
                                title={`${m.name}: ${s}`}
                                className={`
                                w-5 h-5 rounded-full border border-[#0f172a] flex items-center justify-center text-[8px] font-bold text-white shadow-sm z-10
                                ${colors[s]}
                                `}
                            >
                                {m.name.charAt(0)}
                            </div>
                            );
                        })}
                        </div>
                    </div>

                  </div>
                );
              })}
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Footer Action */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#0f172a] to-transparent z-40 flex justify-center items-end pointer-events-none">
        <div className="pointer-events-auto flex flex-col items-center gap-4">
            <div className="md:hidden">
                <ClayButton variant="magic" onClick={onAutoAssign} disabled={isAutoAssigning}>
                    {isAutoAssigning ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                    <span className="ml-2">AI Auto-Assign</span>
                </ClayButton>
            </div>
            <ClayButton onClick={onFinish} className="shadow-2xl !px-12 !py-5">
                Generate Operating Contract <LayoutDashboard className="ml-2" size={20} />
            </ClayButton>
        </div>
      </div>
    </div>
  );
};

// 3. Analytics Dashboard & Contract (Dashboard)
const Dashboard: React.FC<{ 
  project: ProjectInfo, 
  roles: Role[], 
  members: TeamMember[], 
  assignments: Assignment[] 
}> = ({ project, roles, members, assignments }) => {
  const [view, setView] = useState<'charts' | 'contract'>('charts');

  // Metrics Logic
  const coverageData = useMemo(() => {
    let unassigned = 0;
    let singleOwner = 0;
    let multipleOwners = 0;
    let gap = 0; 

    roles.forEach(role => {
      role.tasks.forEach(task => {
        const taskAssignments = assignments.filter(a => a.taskId === task.id);
        const owners = taskAssignments.filter(a => a.type === 'own');
        
        if (owners.length === 0) {
            const supporters = taskAssignments.filter(a => a.type === 'support');
            if(supporters.length > 0) unassigned++; 
            else gap++; 
        } else if (owners.length === 1) {
            singleOwner++;
        } else {
            multipleOwners++;
        }
      });
    });

    return [
      { name: 'Optimized', value: singleOwner, color: '#10b981' }, 
      { name: 'Overlapping', value: multipleOwners, color: '#f43f5e' }, 
      { name: 'Fragile (Sup only)', value: unassigned, color: '#f59e0b' }, 
      { name: 'Critical Gap', value: gap, color: '#64748b' }, 
    ];
  }, [roles, assignments]);

  const memberLoadData = useMemo(() => {
    return members.map(m => {
        const owns = assignments.filter(a => a.memberId === m.id && a.type === 'own').length;
        const supports = assignments.filter(a => a.memberId === m.id && a.type === 'support').length;
        return { name: m.name, owns, supports };
    });
  }, [members, assignments]);

  if (view === 'contract') {
    return (
      <div className="min-h-screen p-4 md:p-8 max-w-5xl mx-auto z-10 relative">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">Project Manifesto</h2>
            <ClayButton variant="secondary" onClick={() => setView('charts')} className="!py-2 !px-4 text-sm">Back to Analytics</ClayButton>
        </div>
        
        <div className="bg-white text-slate-900 rounded-sm min-h-[800px] shadow-[0_0_50px_rgba(255,255,255,0.1)] relative overflow-hidden">
             {/* Print/Paper Aesthetic */}
            <div className="absolute inset-0 bg-[#f8fafc] opacity-90" />
            <div className="absolute top-0 right-0 p-10 opacity-10 pointer-events-none">
                 <Zap size={200} />
            </div>
            
            <div className="relative z-10 p-12">
                <div className="border-b-4 border-slate-900 pb-8 mb-10 flex justify-between items-end">
                    <div>
                        <div className="text-slate-500 text-xs font-bold uppercase tracking-[0.2em] mb-2">Internal Operating Agreement</div>
                        <h1 className="text-5xl font-black tracking-tighter uppercase leading-none">{project.name}</h1>
                        <p className="text-slate-600 mt-4 text-lg font-serif italic max-w-lg">"{project.description}"</p>
                    </div>
                    <div className="text-right hidden sm:block">
                         <div className="inline-block border-2 border-slate-900 p-2 font-mono text-sm">
                             REF: {Math.random().toString(36).substr(2, 6).toUpperCase()}
                         </div>
                         <div className="mt-2 text-sm font-bold">{new Date().toLocaleDateString()}</div>
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-12">
                    {roles.map((role) => (
                        <div key={role.title}>
                            <div className="flex items-center gap-4 mb-6">
                                <h3 className="text-2xl font-bold text-slate-900 uppercase tracking-tight">
                                    {role.title}
                                </h3>
                                <div className="h-px bg-slate-300 flex-grow"></div>
                            </div>
                            
                            <div className="space-y-0">
                                {role.tasks.map((task, i) => {
                                    const taskAssigns = assignments.filter(a => a.taskId === task.id);
                                    const owners = taskAssigns.filter(a => a.type === 'own').map(a => members.find(m => m.id === a.memberId)?.name);
                                    const supporters = taskAssigns.filter(a => a.type === 'support').map(a => members.find(m => m.id === a.memberId)?.name);
                                    
                                    return (
                                        <div key={task.id} className={`grid grid-cols-12 gap-6 py-4 border-b border-slate-100 ${i === 0 ? 'border-t' : ''} hover:bg-slate-50 transition-colors`}>
                                            <div className="col-span-12 md:col-span-6">
                                                <div className="font-bold text-slate-800 text-sm">{task.title}</div>
                                                <div className="text-xs text-slate-500 mt-1">{task.description}</div>
                                            </div>
                                            
                                            <div className="col-span-6 md:col-span-3 flex items-center">
                                                {owners.length > 0 ? (
                                                     <div className="flex -space-x-2">
                                                        {owners.map(name => (
                                                            <span key={name} className="px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-full border-2 border-white shadow-sm">
                                                                {name}
                                                            </span>
                                                        ))}
                                                     </div>
                                                ) : (
                                                    <span className="text-xs font-bold text-red-500 uppercase tracking-widest bg-red-50 px-2 py-1">Unclaimed</span>
                                                )}
                                            </div>

                                            <div className="col-span-6 md:col-span-3 flex items-center">
                                                {supporters.length > 0 ? (
                                                    <div className="flex flex-wrap gap-1">
                                                        {supporters.map(name => (
                                                            <span key={name} className="text-[10px] text-slate-500 border border-slate-200 px-2 py-0.5 rounded-full bg-white">
                                                                {name}
                                                            </span>
                                                        ))}
                                                    </div>
                                                ) : <span className="text-slate-300 text-xs">-</span>}
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-20 pt-10 border-t-2 border-slate-900">
                    <p className="mb-8 font-serif italic text-slate-500 text-center">By signing below, we agree to hold ourselves and each other accountable to these roles.</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
                        {members.map(m => (
                            <div key={m.id} className="text-center group cursor-pointer">
                                <div className="h-16 border-b-2 border-slate-300 flex items-end justify-center pb-2 group-hover:border-blue-600 transition-colors">
                                    <span className="font-script text-2xl text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity -rotate-6 block">
                                        {m.name}
                                    </span>
                                </div>
                                <p className="mt-3 font-bold text-slate-900 uppercase text-xs tracking-wider">{m.name}</p>
                                <p className="text-[10px] text-slate-400 uppercase">Team Member</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 pb-24 z-10 relative flex flex-col items-center">
       <div className="w-full max-w-7xl mb-12 flex flex-col md:flex-row justify-between items-end gap-6">
         <div>
            <h2 className="text-4xl font-extrabold text-white mb-2">Flow Analytics</h2>
            <p className="text-cyan-200/60 max-w-xl">
                Real-time analysis of your team's structural integrity. 
                Green indicates a healthy flow state. Red indicates potential bottlenecks.
            </p>
         </div>
         <ClayButton variant="primary" onClick={() => setView('contract')}>
             Open Operating Contract <FileText className="ml-2" size={18} />
         </ClayButton>
       </div>

       <div className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Task Distribution Chart */}
            <GlassCard className="h-[450px] flex flex-col items-center justify-center lg:col-span-1">
                <h3 className="text-lg font-bold text-cyan-50 mb-6 w-full text-left flex items-center gap-2">
                    <CheckCircle2 size={18} className="text-cyan-400"/> Ownership Health
                </h3>
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={coverageData}
                            cx="50%"
                            cy="50%"
                            innerRadius={80}
                            outerRadius={110}
                            paddingAngle={5}
                            dataKey="value"
                            stroke="none"
                        >
                            {coverageData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Pie>
                        <Tooltip 
                            contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', backdropFilter: 'blur(10px)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff', boxShadow: '0 10px 40px rgba(0,0,0,0.5)' }}
                            itemStyle={{ color: '#fff', fontWeight: 600 }}
                        />
                    </PieChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-2 gap-4 w-full mt-4">
                    {coverageData.map(d => (
                        <div key={d.name} className="flex items-center gap-2 text-xs text-cyan-100/80 bg-white/5 p-2 rounded-lg border border-white/5">
                            <div className="w-2 h-2 rounded-full shadow-[0_0_8px_currentColor]" style={{ backgroundColor: d.color, color: d.color }}></div>
                            <span className="font-semibold">{d.value}</span> {d.name}
                        </div>
                    ))}
                </div>
            </GlassCard>

            {/* Workload Chart */}
            <GlassCard className="h-[450px] lg:col-span-2">
                <h3 className="text-lg font-bold text-cyan-50 mb-6 w-full text-left flex items-center gap-2">
                    <Users size={18} className="text-blue-400"/> Load Balancer
                </h3>
                <ResponsiveContainer width="100%" height="85%">
                    <BarChart
                        data={memberLoadData}
                        margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                        barSize={40}
                    >
                        <XAxis dataKey="name" stroke="#94a3b8" tick={{fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                        <YAxis stroke="#94a3b8" tick={{fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                        <Tooltip 
                            cursor={{fill: 'rgba(255,255,255,0.03)'}}
                            contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', backdropFilter: 'blur(10px)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} 
                        />
                        <Bar dataKey="owns" name="Primary Owner" stackId="a" fill="#10b981" radius={[0, 0, 4, 4]} />
                        <Bar dataKey="supports" name="Supporting" stackId="a" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </GlassCard>
       </div>

       {/* Smart Insights */}
       <div className="w-full max-w-7xl grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-3">
              <h3 className="text-sm font-bold text-cyan-200/50 uppercase tracking-widest mb-4 ml-2">AI Insights</h3>
          </div>
          
          {coverageData.find(d => d.name.includes('Gap'))?.value! > 0 ? (
             <div className="bg-rose-500/10 backdrop-blur-md border border-rose-500/20 rounded-2xl p-6 flex items-start gap-4">
                 <div className="p-3 bg-rose-500/20 rounded-xl">
                    <AlertCircle className="text-rose-400" size={24} />
                 </div>
                 <div>
                     <p className="text-rose-200 font-bold text-lg">Critical Gaps Detected</p>
                     <p className="text-rose-200/60 text-sm mt-1 leading-relaxed">
                        {coverageData.find(d => d.name.includes('Gap'))?.value} tasks are currently orphaned. 
                        Consider assigning "Support" roles to Junior members or using the AI Auto-Assign tool.
                     </p>
                 </div>
             </div>
          ) : (
            <div className="bg-emerald-500/10 backdrop-blur-md border border-emerald-500/20 rounded-2xl p-6 flex items-start gap-4">
                 <div className="p-3 bg-emerald-500/20 rounded-xl">
                    <CheckCircle2 className="text-emerald-400" size={24} />
                 </div>
                 <div>
                     <p className="text-emerald-200 font-bold text-lg">Full Coverage</p>
                     <p className="text-emerald-200/60 text-sm mt-1">
                        All tasks have a primary owner. The structural integrity of the project is sound.
                     </p>
                 </div>
             </div>
          )}

          {coverageData.find(d => d.name.includes('Overlapping'))?.value! > 0 && (
             <div className="bg-orange-500/10 backdrop-blur-md border border-orange-500/20 rounded-2xl p-6 flex items-start gap-4">
                 <div className="p-3 bg-orange-500/20 rounded-xl">
                    <Share2 className="text-orange-400" size={24} />
                 </div>
                 <div>
                     <p className="text-orange-200 font-bold text-lg">Ownership Conflicts</p>
                     <p className="text-orange-200/60 text-sm mt-1 leading-relaxed">
                        {coverageData.find(d => d.name.includes('Overlapping'))?.value} tasks have multiple primary owners. 
                        This often leads to ambiguity. Designate one person as "Support".
                     </p>
                 </div>
             </div>
          )}

           <div className="bg-blue-500/10 backdrop-blur-md border border-blue-500/20 rounded-2xl p-6 flex items-start gap-4">
                 <div className="p-3 bg-blue-500/20 rounded-xl">
                    <Zap className="text-blue-400" size={24} />
                 </div>
                 <div>
                     <p className="text-blue-200 font-bold text-lg">Velocity Potential</p>
                     <p className="text-blue-200/60 text-sm mt-1 leading-relaxed">
                        Based on current distribution, the team has a high capacity for execution. 
                        Ensure the {memberLoadData.sort((a,b) => b.owns - a.owns)[0]?.name} is not bottlenecked.
                     </p>
                 </div>
             </div>
       </div>
    </div>
  );
};

// --- Main App Component ---

const App: React.FC = () => {
  const [stage, setStage] = useState<'setup' | 'claiming' | 'dashboard'>('setup');
  const [isLoading, setIsLoading] = useState(false);
  const [isAutoAssigning, setIsAutoAssigning] = useState(false);
  const [project, setProject] = useState<ProjectInfo | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);

  const handleSetupComplete = async (info: ProjectInfo) => {
    setIsLoading(true);
    try {
      setProject(info);
      
      const generatedMembers: TeamMember[] = Array.from({ length: info.teamSize }).map((_, i) => ({
        id: `m-${i}`,
        name: `Member ${i + 1}`,
        avatarColor: ['#06b6d4', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b'][i % 5]
      }));
      setMembers(generatedMembers);

      const plan = await generateRoleMap(info);
      setRoles(plan.roles);
      
      setStage('claiming');
    } catch (e) {
      console.error(e);
      alert("Failed to generate plan. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAssignment = (taskId: string, memberId: string, type: Assignment['type']) => {
    setAssignments(prev => {
        const clean = prev.filter(a => !(a.taskId === taskId && a.memberId === memberId));
        if (type === null) return clean;
        return [...clean, { taskId, memberId, type }];
    });
  };

  const handleAutoAssign = async () => {
    if(!project || roles.length === 0) return;
    setIsAutoAssigning(true);
    try {
        const suggested = await suggestAssignments(project, roles, members);
        // Merge with existing assignments, prioritizing existing human choices? 
        // For now, let's just append/overwrite based on the AI's wisdom if it's not set.
        // Or cleaner: Replace entirely or fill gaps. Let's fill gaps.
        
        setAssignments(prev => {
             const newAssignments = [...prev];
             suggested.forEach(s => {
                 // Only add if this specific task assignment doesn't exist for this user
                 if (!newAssignments.some(a => a.taskId === s.taskId && a.memberId === s.memberId)) {
                     newAssignments.push(s);
                 }
             });
             return newAssignments;
        });
    } catch(e) {
        console.error("Auto assign failed", e);
    } finally {
        setIsAutoAssigning(false);
    }
  }

  return (
    <div className="min-h-screen text-cyan-50 selection:bg-cyan-500/30 liquid-bg font-['Outfit']">
      <FloatingOrbs />
      
      <main className="relative z-10">
        {stage === 'setup' && (
          <ProjectSetup onComplete={handleSetupComplete} isLoading={isLoading} />
        )}
        
        {stage === 'claiming' && project && (
          <TaskClaimBoard 
            project={project} 
            roles={roles} 
            members={members}
            assignments={assignments}
            onAssign={handleAssignment}
            onAutoAssign={handleAutoAssign}
            onFinish={() => setStage('dashboard')}
            isAutoAssigning={isAutoAssigning}
          />
        )}

        {stage === 'dashboard' && project && (
          <Dashboard 
            project={project} 
            roles={roles} 
            members={members} 
            assignments={assignments} 
          />
        )}
      </main>
    </div>
  );
};

export default App;