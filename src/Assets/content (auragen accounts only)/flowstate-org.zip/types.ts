export interface ProjectInfo {
  name: string;
  description: string;
  teamSize: number;
}

export type OwnershipType = 'own' | 'support' | 'avoid' | null;

export interface Task {
  id: string;
  role: string;
  title: string;
  description: string;
}

export interface Role {
  title: string;
  description: string;
  tasks: Task[];
}

export interface TeamMember {
  id: string;
  name: string;
  avatarColor: string;
}

export interface Assignment {
  taskId: string;
  memberId: string;
  type: OwnershipType;
}

export interface GeneratedPlan {
  roles: Role[];
}
