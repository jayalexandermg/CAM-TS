import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css'; // Assuming styles are injected via style tag in HTML, but standard practice involves CSS import if available. 
// Since we are using a single file HTML structure with style tag, we just mount.

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);