// Data
const decisionFramework = [
  { scenario: "Internal/Proprietary Tools", build_custom_mcp: "Yes", use_existing_api: "No", reasoning: "No public MCP servers exist for proprietary internal tools. Custom MCP allows AI agents to access company-specific systems securely.", dev_time: "160-260 hours", roi: "High - Enables new capabilities" },
  { scenario: "Legacy System Integration", build_custom_mcp: "Yes", use_existing_api: "Maybe", reasoning: "Existing MCP servers won't integrate with legacy systems. Custom servers can wrap old APIs and expose them to AI agents.", dev_time: "240-400 hours", roi: "Medium - Reduces manual work" },
  { scenario: "High-Frequency Operations", build_custom_mcp: "No", use_existing_api: "Yes", reasoning: "MCP adds reasoning layer latency. Direct API calls provide better performance for time-sensitive operations (IoT, trading, monitoring).", dev_time: "N/A - Use API", roi: "N/A" },
  { scenario: "Simple CRUD Operations", build_custom_mcp: "Maybe", use_existing_api: "Yes", reasoning: "For basic database operations, direct API calls may be simpler. Custom MCP is worthwhile if you need dynamic tool discovery across teams.", dev_time: "60-110 hours", roi: "Low - Simple alternatives exist" },
  { scenario: "Complex Multi-Step Workflows", build_custom_mcp: "Yes", use_existing_api: "No", reasoning: "Custom MCP excels at multi-agent orchestration. Can combine database queries, API calls, and business logic in one conversational interface.", dev_time: "240-400 hours", roi: "High - 30%+ efficiency gains" },
  { scenario: "Specialized Business Logic", build_custom_mcp: "Yes", use_existing_api: "No", reasoning: "When business rules are complex and domain-specific, custom MCP servers can encode expert knowledge and make it AI-accessible.", dev_time: "160-400 hours", roi: "High - Competitive advantage" },
  { scenario: "Common SaaS Tools (Slack, GitHub, etc.)", build_custom_mcp: "No", use_existing_api: "Yes", reasoning: "Use existing MCP servers from vendor/community. Building custom adds unnecessary maintenance burden.", dev_time: "N/A - Use existing", roi: "N/A" },
  { scenario: "Real-time Data Analytics", build_custom_mcp: "No", use_existing_api: "Yes", reasoning: "Direct API integration with existing BI tools is more efficient. MCP's conversational layer adds overhead without clear benefit.", dev_time: "N/A - Use API", roi: "N/A" },
  { scenario: "Cross-Repository Development", build_custom_mcp: "Yes", use_existing_api: "Maybe", reasoning: "Custom filesystem MCP can track issues across multiple repos. Saves hours of manual investigation for debugging spanning services.", dev_time: "110-160 hours", roi: "High - Saves hours per debugging session" },
  { scenario: "Custom Database Schema", build_custom_mcp: "Yes", use_existing_api: "Maybe", reasoning: "Poorly documented databases benefit from custom PostgreSQL/MySQL MCP that understands your specific schema and relationships.", dev_time: "110-160 hours", roi: "High - 70-80% reduction in query time" },
  { scenario: "High Security Requirements", build_custom_mcp: "Yes", use_existing_api: "No", reasoning: "Custom MCP allows fine-grained authorization, audit logging, and compliance controls tailored to your security policies.", dev_time: "240-400 hours", roi: "High - Reduces security incidents 60%" },
  { scenario: "Enterprise-Wide Tool Standardization", build_custom_mcp: "Yes", use_existing_api: "No", reasoning: "Building internal MCP servers creates reusable tool layer. Multiple teams can leverage same integrations without rebuilding.", dev_time: "400-650 hours", roi: "Very High - Shared across organization" }
];

const realWorldExamples = [
  { company: "Block (Payment Processing)", use_case: "Agentic systems for payment processing automation", mcp_type: "Custom", key_benefit: "Removes mechanical burden, enables creative focus", roi: "High - Foundation for public good technology", build_vs_buy: "Build - Proprietary payment systems", industry: "FinTech" },
  { company: "Apollo (Developer Tools)", use_case: "Enhanced AI-driven code analysis and debugging", mcp_type: "Custom", key_benefit: "Better context understanding for complex codebases", roi: "High - Enhanced developer productivity", build_vs_buy: "Build - Custom codebase context", industry: "Developer Tools" },
  { company: "Reddit User - Cross-Service Debugging", use_case: "Debug issues spanning 5+ microservice repositories", mcp_type: "Custom (Filesystem)", key_benefit: "Found API contract discrepancies in days of failed debugging", roi: "Very High - Saved days of debugging time", build_vs_buy: "Build - Internal microservices architecture", industry: "Software Development" },
  { company: "Reddit User - Database Management", use_case: "Query poorly documented PostgreSQL database schemas", mcp_type: "Custom (PostgreSQL)", key_benefit: "Answers require hours of manual investigation → seconds", roi: "Very High - 70-80% reduction in investigation time", build_vs_buy: "Build - Undocumented legacy schema", industry: "Data Management" },
  { company: "E-commerce Platform", use_case: "Automated order tracking, refunds, and inventory management", mcp_type: "Hybrid (Custom + Existing)", key_benefit: "40% fewer support tickets, 3x faster response times", roi: "Very High - 40% ticket reduction = cost savings", build_vs_buy: "Hybrid - Use existing for standard tools, custom for business logic", industry: "E-commerce" },
  { company: "Financial Services Firm", use_case: "Fraud detection with real-time transaction analysis", mcp_type: "Custom", key_benefit: "50% reduction in false positives (PayPal example)", roi: "Very High - 50% false positive reduction", build_vs_buy: "Build - Compliance and security requirements", industry: "Financial Services" },
  { company: "Healthcare Organization", use_case: "EMR-linked agents reducing physician admin time", mcp_type: "Custom", key_benefit: "Streamlined operations across real-time and legacy systems", roi: "High - Physician time savings = more patient care", build_vs_buy: "Build - HIPAA compliance, custom EMR integration", industry: "Healthcare" },
  { company: "Logistics Company (SuperAGI Case)", use_case: "Autonomous route optimization and delivery coordination", mcp_type: "Custom", key_benefit: "30% reduction in operational costs, 25% delivery efficiency improvement", roi: "Very High - 30% cost reduction, 20% customer satisfaction increase", build_vs_buy: "Build - Proprietary routing algorithms", industry: "Logistics" },
  { company: "Manufacturing (IoT)", use_case: "Predictive maintenance across edge and cloud systems", mcp_type: "Custom (IoT)", key_benefit: "Reduces downtime through proactive system optimization", roi: "High - 40% improvement in system efficiency", build_vs_buy: "Build - Custom IoT infrastructure", industry: "Manufacturing" },
  { company: "Legal Services Firm", use_case: "Case document summarization and legal research", mcp_type: "Hybrid", key_benefit: "High-stakes workflow automation with compliance", roi: "High - Critical for compliance-heavy sector", build_vs_buy: "Hybrid - Standard legal research tools + custom case management", industry: "Legal Services" },
  { company: "EdTech Platform", use_case: "Personalized learning path generation", mcp_type: "Hybrid", key_benefit: "Personalized experiences at scale", roi: "High - Improved learning outcomes", build_vs_buy: "Hybrid - Standard LMS + custom curriculum logic", industry: "Education" },
  { company: "Developer Productivity (GitHub Integration)", use_case: "Automated PR reviews, issue triage, and repo management", mcp_type: "Existing (Community)", key_benefit: "Automated documentation updates during feature rollout", roi: "High - Hours saved weekly on documentation", build_vs_buy: "Buy/Use - GitHub MCP server widely available", industry: "Developer Tools" },
  { company: "Customer Support SaaS", use_case: "Ticket creation, routing, and resolution automation", mcp_type: "Custom", key_benefit: "Intelligent routing based on ticket context and history", roi: "High - Faster resolution = customer retention", build_vs_buy: "Build - Company-specific ticketing system", industry: "SaaS" },
  { company: "Marketing Agency (Multi-Client)", use_case: "Campaign performance tracking across client accounts", mcp_type: "Custom", key_benefit: "Single interface to multiple client CRMs and ad platforms", roi: "High - Single integration serves multiple clients", build_vs_buy: "Build - Multi-tenant client data access", industry: "Marketing" },
  { company: "Research Lab (Drug Discovery)", use_case: "Track experimental workflows and drug compound analysis", mcp_type: "Custom", key_benefit: "Context maintained across multi-step experiments", roi: "High - Reproducible experiments, faster discovery", build_vs_buy: "Build - Specialized research workflows", industry: "Research" }
];

const costData = {
  basic: {
    development: 20000, year1_compute: 600, year1_storage: 20, year1_egress: 100, year1_apis: 1200, year1_monitoring: 50, year1_maintenance: 12000,
    year2plus_compute: 600, year2plus_storage: 20, year2plus_egress: 100, year2plus_apis: 1200, year2plus_monitoring: 50, year2plus_maintenance: 12000
  },
  medium: {
    development: 24000, year1_compute: 840, year1_storage: 30, year1_egress: 432, year1_apis: 5400, year1_monitoring: 126, year1_maintenance: 24000,
    year2plus_compute: 840, year2plus_storage: 30, year2plus_egress: 432, year2plus_apis: 5400, year2plus_monitoring: 126, year2plus_maintenance: 24000
  },
  complex: {
    development: 48000, year1_compute: 2500, year1_storage: 100, year1_egress: 1500, year1_apis: 15000, year1_monitoring: 500, year1_maintenance: 48000,
    year2plus_compute: 2500, year2plus_storage: 100, year2plus_egress: 1500, year2plus_apis: 15000, year2plus_monitoring: 500, year2plus_maintenance: 48000
  }
};

const apiVsMcp = [
  { dimension: "Integration Pattern", api: "Hard-coded endpoints, requires developers to write integration code", mcp: "Real-time negotiation, server provides tools dynamically", when_api: "Simple, repetitive operations", when_mcp: "Dynamic tool discovery needed" },
  { dimension: "State Management", api: "Stateless - each request independent", mcp: "Stateful - maintains session context", when_api: "Independent operations", when_mcp: "Multi-step workflows" },
  { dimension: "Performance", api: "High - direct calls, <100ms latency", mcp: "Medium - adds 200-500ms for reasoning", when_api: "Performance-critical systems", when_mcp: "Flexibility matters more than speed" },
  { dimension: "Scalability", api: "Very High - decades of optimization", mcp: "Moderate - session-based challenges", when_api: "High-volume processing", when_mcp: "Internal tools, moderate scale" },
  { dimension: "Development", api: "Medium - API-specific code each time", mcp: "High initial (60-650 hrs), then reusable", when_api: "One-off integrations", when_mcp: "Reusable across projects" },
  { dimension: "Discovery", api: "Static documentation", mcp: "Dynamic runtime discovery", when_api: "Known, stable endpoints", when_mcp: "Evolving capabilities" },
  { dimension: "Best For", api: "Deterministic operations, bulk data", mcp: "AI agents, conversational interfaces", when_api: "Traditional software", when_mcp: "AI-native applications" },
  { dimension: "Security", api: "Standard OAuth, API keys", mcp: "New risks: tool poisoning, session hijacking", when_api: "Well-understood security model", when_mcp: "Need runtime guardrails" }
];

// State Management
let currentView = 'overview';
let currentTheme = 'light';
let filteredDecisionData = [...decisionFramework];
let filteredExamplesData = [...realWorldExamples];
let sortColumn = '';
let sortDirection = 'asc';
let costChart = null;
let wizardAnswers = {};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  initializeApp();
});

function initializeApp() {
  setupNavigation();
  setupThemeToggle();
  renderOverviewStats();
  renderDecisionFramework();
  renderExamples();
  renderCostCalculator();
  renderComparison();
  setupFilters();
  setupModal();
  setupWizard();
  updateBreadcrumb();
}

// Navigation
function setupNavigation() {
  const navButtons = document.querySelectorAll('.nav-btn');
  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const view = btn.dataset.view;
      switchView(view);
    });
  });

  const actionCards = document.querySelectorAll('.action-card');
  actionCards.forEach(card => {
    card.addEventListener('click', () => {
      const view = card.dataset.navigate;
      switchView(view);
    });
  });
}

function switchView(view) {
  currentView = view;
  
  // Update views
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`view-${view}`).classList.add('active');
  
  // Update navigation
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });
  
  updateBreadcrumb();
  window.scrollTo(0, 0);
}

function updateBreadcrumb() {
  const breadcrumb = document.getElementById('breadcrumb');
  const viewNames = {
    overview: 'Overview',
    decision: 'Decision Framework',
    examples: 'Real-World Examples',
    calculator: 'Cost Calculator',
    comparison: 'API vs MCP'
  };
  breadcrumb.textContent = `Home > ${viewNames[currentView]}`;
}

// Theme Toggle
function setupThemeToggle() {
  const themeToggle = document.getElementById('themeToggle');
  themeToggle.addEventListener('click', () => {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', currentTheme);
    themeToggle.querySelector('.theme-icon').textContent = currentTheme === 'light' ? '🌙' : '☀️';
    
    // Update chart if it exists
    if (costChart) {
      updateCostChart();
    }
  });
}

// Overview Stats
function renderOverviewStats() {
  document.getElementById('stat-examples').textContent = realWorldExamples.length;
  document.getElementById('stat-time').textContent = '60-650h';
  const highRoi = decisionFramework.filter(d => d.roi.includes('High')).length;
  document.getElementById('stat-roi').textContent = highRoi;
  const industries = new Set(realWorldExamples.map(e => e.industry)).size;
  document.getElementById('stat-industries').textContent = industries;
}

// Decision Framework
function renderDecisionFramework() {
  renderDecisionTable();
  renderDecisionCards();
  
  // View toggle
  const viewToggles = document.querySelectorAll('.view-toggle-btn');
  viewToggles.forEach(btn => {
    btn.addEventListener('click', () => {
      const viewType = btn.dataset.viewType;
      viewToggles.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      if (viewType === 'table') {
        document.getElementById('decisionTableView').style.display = 'block';
        document.getElementById('decisionCardsView').style.display = 'none';
      } else {
        document.getElementById('decisionTableView').style.display = 'none';
        document.getElementById('decisionCardsView').style.display = 'grid';
      }
    });
  });
}

function renderDecisionTable() {
  const tbody = document.getElementById('decisionTableBody');
  tbody.innerHTML = '';
  
  filteredDecisionData.forEach(item => {
    const tr = document.createElement('tr');
    tr.className = `row-${item.build_custom_mcp.toLowerCase()}`;
    
    const roiClass = item.roi.split(' - ')[0].toLowerCase().replace(' ', '-');
    
    tr.innerHTML = `
      <td><strong>${item.scenario}</strong></td>
      <td><span class="badge badge-${item.build_custom_mcp.toLowerCase()}">${item.build_custom_mcp}</span></td>
      <td>${item.use_existing_api}</td>
      <td>${item.dev_time}</td>
      <td><span class="badge badge-roi ${roiClass}">${item.roi.split(' - ')[0]}</span></td>
      <td><button class="btn-small" onclick="showScenarioDetail('${item.scenario}')">Details</button></td>
    `;
    tbody.appendChild(tr);
  });
  
  // Add sorting
  const headers = document.querySelectorAll('#decisionTable th[data-sort]');
  headers.forEach(header => {
    header.addEventListener('click', () => {
      const column = header.dataset.sort;
      sortDecisionData(column);
    });
  });
}

function renderDecisionCards() {
  const container = document.getElementById('decisionCardsView');
  container.innerHTML = '';
  
  filteredDecisionData.forEach(item => {
    const card = document.createElement('div');
    card.className = 'scenario-card';
    
    const roiClass = item.roi.split(' - ')[0].toLowerCase().replace(' ', '-');
    
    card.innerHTML = `
      <div class="card-header">
        <h3 class="card-title">${item.scenario}</h3>
        <div class="card-badges">
          <span class="badge badge-${item.build_custom_mcp.toLowerCase()}">${item.build_custom_mcp}</span>
          <span class="badge badge-roi ${roiClass}">${item.roi.split(' - ')[0]}</span>
        </div>
      </div>
      <div class="card-body">
        <p class="card-meta"><strong>Development Time:</strong> ${item.dev_time}</p>
        <p>${item.reasoning.substring(0, 150)}...</p>
      </div>
      <div class="card-footer">
        <button class="btn-small" onclick="showScenarioDetail('${item.scenario}')">View Details</button>
      </div>
    `;
    container.appendChild(card);
  });
}

function sortDecisionData(column) {
  if (sortColumn === column) {
    sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    sortColumn = column;
    sortDirection = 'asc';
  }
  
  filteredDecisionData.sort((a, b) => {
    let aVal = a[column];
    let bVal = b[column];
    
    if (sortDirection === 'asc') {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });
  
  renderDecisionTable();
  renderDecisionCards();
}

// Real-World Examples
function renderExamples() {
  const container = document.getElementById('examplesGrid');
  container.innerHTML = '';
  
  // Populate industry filter
  const industries = [...new Set(realWorldExamples.map(e => e.industry))].sort();
  const industryFilter = document.getElementById('industryFilter');
  industries.forEach(industry => {
    const option = document.createElement('option');
    option.value = industry;
    option.textContent = industry;
    industryFilter.appendChild(option);
  });
  
  filteredExamplesData.forEach(example => {
    const card = document.createElement('div');
    card.className = 'example-card';
    
    const roiClass = example.roi.split(' - ')[0].toLowerCase().replace(' ', '-');
    const mcpTypeClass = example.mcp_type.split(' ')[0].toLowerCase();
    
    card.innerHTML = `
      <div class="card-header">
        <h3 class="card-company">${example.company}</h3>
        <p class="card-industry">${example.industry}</p>
        <div class="card-badges">
          <span class="badge badge-${mcpTypeClass}">${example.mcp_type}</span>
          <span class="badge badge-roi ${roiClass}">${example.roi.split(' - ')[0]}</span>
        </div>
      </div>
      <div class="card-body">
        <p class="card-use-case"><strong>Use Case:</strong> ${example.use_case}</p>
        <div class="card-benefit">
          <strong>Key Benefit:</strong> ${example.key_benefit}
        </div>
        <p class="card-meta"><strong>Decision:</strong> ${example.build_vs_buy}</p>
      </div>
    `;
    container.appendChild(card);
  });
}

function filterExamples() {
  const mcpType = document.getElementById('mcpTypeFilter').value;
  const industry = document.getElementById('industryFilter').value;
  const search = document.getElementById('exampleSearch').value.toLowerCase();
  
  filteredExamplesData = realWorldExamples.filter(example => {
    const matchType = mcpType === 'all' || example.mcp_type.includes(mcpType);
    const matchIndustry = industry === 'all' || example.industry === industry;
    const matchSearch = search === '' || 
      example.company.toLowerCase().includes(search) ||
      example.use_case.toLowerCase().includes(search) ||
      example.key_benefit.toLowerCase().includes(search);
    
    return matchType && matchIndustry && matchSearch;
  });
  
  // Sort
  const sortBy = document.getElementById('sortExamples').value;
  if (sortBy === 'company') {
    filteredExamplesData.sort((a, b) => a.company.localeCompare(b.company));
  } else if (sortBy === 'roi') {
    filteredExamplesData.sort((a, b) => {
      const roiOrder = { 'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
      const aRoi = roiOrder[a.roi.split(' - ')[0]] || 0;
      const bRoi = roiOrder[b.roi.split(' - ')[0]] || 0;
      return bRoi - aRoi;
    });
  } else if (sortBy === 'type') {
    filteredExamplesData.sort((a, b) => a.mcp_type.localeCompare(b.mcp_type));
  }
  
  renderExamples();
}

// Cost Calculator
function renderCostCalculator() {
  updateCostCalculation();
  
  document.getElementById('complexityLevel').addEventListener('change', updateCostCalculation);
  document.getElementById('planningHorizon').addEventListener('input', (e) => {
    document.getElementById('horizonValue').textContent = e.target.value;
    updateCostCalculation();
  });
}

function updateCostCalculation() {
  const complexity = document.getElementById('complexityLevel').value;
  const years = parseInt(document.getElementById('planningHorizon').value);
  const data = costData[complexity];
  
  // Calculate totals
  const year1Total = data.development + data.year1_compute + data.year1_storage + 
    data.year1_egress + data.year1_apis + data.year1_monitoring + data.year1_maintenance;
  
  const yearlyOpex = data.year2plus_compute + data.year2plus_storage + 
    data.year2plus_egress + data.year2plus_apis + data.year2plus_monitoring + data.year2plus_maintenance;
  
  const totalCost = year1Total + (yearlyOpex * (years - 1));
  
  // Update display
  document.getElementById('totalCost').textContent = `$${totalCost.toLocaleString()}`;
  document.getElementById('costPeriod').textContent = `over ${years} year${years > 1 ? 's' : ''}`;
  document.getElementById('year1Cost').textContent = `$${year1Total.toLocaleString()}`;
  document.getElementById('opexCost').textContent = `$${yearlyOpex.toLocaleString()}`;
  
  // Update table
  renderCostTable(data, years);
  
  // Update chart
  updateCostChart();
  
  // Update comparison
  renderComplexityComparison(years);
}

function renderCostTable(data, years) {
  const tbody = document.getElementById('costTableBody');
  tbody.innerHTML = '';
  
  for (let year = 1; year <= years; year++) {
    const tr = document.createElement('tr');
    
    const development = year === 1 ? data.development : 0;
    const compute = year === 1 ? data.year1_compute : data.year2plus_compute;
    const storage = year === 1 ? data.year1_storage : data.year2plus_storage;
    const apis = year === 1 ? data.year1_apis : data.year2plus_apis;
    const maintenance = year === 1 ? data.year1_maintenance : data.year2plus_maintenance;
    const total = development + compute + storage + apis + maintenance;
    
    tr.innerHTML = `
      <td>Year ${year}</td>
      <td>$${development.toLocaleString()}</td>
      <td>$${compute.toLocaleString()}</td>
      <td>$${storage.toLocaleString()}</td>
      <td>$${apis.toLocaleString()}</td>
      <td>$${maintenance.toLocaleString()}</td>
      <td><strong>$${total.toLocaleString()}</strong></td>
    `;
    tbody.appendChild(tr);
  }
}

function updateCostChart() {
  const complexity = document.getElementById('complexityLevel').value;
  const years = parseInt(document.getElementById('planningHorizon').value);
  const data = costData[complexity];
  
  const labels = [];
  const developmentData = [];
  const computeData = [];
  const storageData = [];
  const apisData = [];
  const maintenanceData = [];
  
  for (let year = 1; year <= years; year++) {
    labels.push(`Year ${year}`);
    developmentData.push(year === 1 ? data.development : 0);
    computeData.push(year === 1 ? data.year1_compute : data.year2plus_compute);
    storageData.push(year === 1 ? data.year1_storage : data.year2plus_storage);
    apisData.push(year === 1 ? data.year1_apis : data.year2plus_apis);
    maintenanceData.push(year === 1 ? data.year1_maintenance : data.year2plus_maintenance);
  }
  
  const ctx = document.getElementById('costChart');
  
  if (costChart) {
    costChart.destroy();
  }
  
  const isDark = currentTheme === 'dark';
  const textColor = isDark ? '#f5f5f5' : '#134252';
  const gridColor = isDark ? 'rgba(119, 124, 124, 0.2)' : 'rgba(94, 82, 64, 0.2)';
  
  costChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        { label: 'Development', data: developmentData, backgroundColor: '#1FB8CD' },
        { label: 'Cloud Compute', data: computeData, backgroundColor: '#FFC185' },
        { label: 'Storage', data: storageData, backgroundColor: '#B4413C' },
        { label: 'APIs', data: apisData, backgroundColor: '#5D878F' },
        { label: 'Maintenance', data: maintenanceData, backgroundColor: '#D2BA4C' }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: { color: textColor }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
            }
          }
        }
      },
      scales: {
        x: {
          stacked: true,
          ticks: { color: textColor },
          grid: { color: gridColor }
        },
        y: {
          stacked: true,
          ticks: {
            color: textColor,
            callback: function(value) {
              return '$' + value.toLocaleString();
            }
          },
          grid: { color: gridColor }
        }
      }
    }
  });
}

function renderComplexityComparison(years) {
  const container = document.getElementById('complexityComparison');
  container.innerHTML = '';
  
  ['basic', 'medium', 'complex'].forEach(level => {
    const data = costData[level];
    const year1Total = data.development + data.year1_compute + data.year1_storage + 
      data.year1_egress + data.year1_apis + data.year1_monitoring + data.year1_maintenance;
    const yearlyOpex = data.year2plus_compute + data.year2plus_storage + 
      data.year2plus_egress + data.year2plus_apis + data.year2plus_monitoring + data.year2plus_maintenance;
    const totalCost = year1Total + (yearlyOpex * (years - 1));
    
    const div = document.createElement('div');
    div.className = 'comparison-item';
    div.innerHTML = `
      <h4>${level.charAt(0).toUpperCase() + level.slice(1)}</h4>
      <div class="cost-line"><span>Development</span><span>$${data.development.toLocaleString()}</span></div>
      <div class="cost-line"><span>Year 1 OpEx</span><span>$${(year1Total - data.development).toLocaleString()}</span></div>
      <div class="cost-line"><span>Yearly OpEx</span><span>$${yearlyOpex.toLocaleString()}</span></div>
      <div class="total-line"><span>Total (${years}y)</span><span>$${totalCost.toLocaleString()}</span></div>
    `;
    container.appendChild(div);
  });
}

// API vs MCP Comparison
function renderComparison() {
  const tbody = document.getElementById('comparisonTableBody');
  tbody.innerHTML = '';
  
  apiVsMcp.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="sticky-col">${item.dimension}</td>
      <td>${item.api}</td>
      <td>${item.mcp}</td>
      <td><strong>API:</strong> ${item.when_api}<br><strong>MCP:</strong> ${item.when_mcp}</td>
    `;
    tbody.appendChild(tr);
  });
}

// Filters
function setupFilters() {
  document.getElementById('buildFilter').addEventListener('change', filterDecisionData);
  document.getElementById('roiFilter').addEventListener('change', filterDecisionData);
  document.getElementById('scenarioSearch').addEventListener('input', filterDecisionData);
  
  document.getElementById('mcpTypeFilter').addEventListener('change', filterExamples);
  document.getElementById('industryFilter').addEventListener('change', filterExamples);
  document.getElementById('exampleSearch').addEventListener('input', filterExamples);
  document.getElementById('sortExamples').addEventListener('change', filterExamples);
}

function filterDecisionData() {
  const buildFilter = document.getElementById('buildFilter').value;
  const roiFilter = document.getElementById('roiFilter').value;
  const search = document.getElementById('scenarioSearch').value.toLowerCase();
  
  filteredDecisionData = decisionFramework.filter(item => {
    const matchBuild = buildFilter === 'all' || item.build_custom_mcp === buildFilter;
    const matchRoi = roiFilter === 'all' || item.roi.includes(roiFilter);
    const matchSearch = search === '' || 
      item.scenario.toLowerCase().includes(search) ||
      item.reasoning.toLowerCase().includes(search);
    
    return matchBuild && matchRoi && matchSearch;
  });
  
  renderDecisionTable();
  renderDecisionCards();
}

// Modal
function setupModal() {
  const modal = document.getElementById('scenarioModal');
  const closeBtn = document.getElementById('closeModal');
  
  closeBtn.addEventListener('click', () => {
    modal.classList.remove('active');
  });
  
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('active');
    }
  });
}

function showScenarioDetail(scenario) {
  const item = decisionFramework.find(d => d.scenario === scenario);
  if (!item) return;
  
  const modal = document.getElementById('scenarioModal');
  const modalBody = document.getElementById('modalBody');
  
  modalBody.innerHTML = `
    <h2>${item.scenario}</h2>
    <div class="modal-section">
      <h3>Decision</h3>
      <p><strong>Build Custom MCP:</strong> <span class="badge badge-${item.build_custom_mcp.toLowerCase()}">${item.build_custom_mcp}</span></p>
      <p><strong>Use Existing/API:</strong> ${item.use_existing_api}</p>
    </div>
    <div class="modal-section">
      <h3>Reasoning</h3>
      <p>${item.reasoning}</p>
    </div>
    <div class="modal-section">
      <h3>Investment</h3>
      <p><strong>Development Time:</strong> ${item.dev_time}</p>
      <p><strong>ROI:</strong> ${item.roi}</p>
    </div>
  `;
  
  modal.classList.add('active');
}

// Wizard
function setupWizard() {
  document.getElementById('startWizard').addEventListener('click', () => {
    wizardAnswers = {};
    showWizardStep(1);
    document.getElementById('wizardModal').classList.add('active');
  });
  
  document.getElementById('closeWizard').addEventListener('click', () => {
    document.getElementById('wizardModal').classList.remove('active');
  });
  
  document.getElementById('wizardRestart').addEventListener('click', () => {
    wizardAnswers = {};
    showWizardStep(1);
  });
  
  // Wizard options
  document.querySelectorAll('.wizard-option').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const answer = e.target.dataset.answer;
      const currentStep = parseInt(e.target.closest('.wizard-step').id.replace('wizardStep', ''));
      wizardAnswers[`step${currentStep}`] = answer;
      
      if (currentStep < 3) {
        showWizardStep(currentStep + 1);
      } else {
        showWizardResult();
      }
    });
  });
}

function showWizardStep(step) {
  for (let i = 1; i <= 3; i++) {
    document.getElementById(`wizardStep${i}`).style.display = i === step ? 'block' : 'none';
  }
  document.getElementById('wizardResult').style.display = 'none';
}

function showWizardResult() {
  document.querySelectorAll('.wizard-step').forEach(step => step.style.display = 'none');
  const resultDiv = document.getElementById('wizardResult');
  resultDiv.style.display = 'block';
  
  // Simple decision logic
  let recommendation = '';
  const { step1, step2, step3 } = wizardAnswers;
  
  if (step1 === 'saas') {
    recommendation = `
      <div class="recommendation-box">
        <h4>Recommendation: Use Existing MCP Servers</h4>
        <p>For common SaaS tools, there are likely existing MCP servers available from vendors or the community. Building a custom server would add unnecessary maintenance burden.</p>
        <p><strong>Next Steps:</strong> Check the MCP server registry for existing integrations.</p>
      </div>
    `;
  } else if (step2 === 'realtime') {
    recommendation = `
      <div class="recommendation-box">
        <h4>Recommendation: Use Direct API Integration</h4>
        <p>For real-time, high-frequency operations, MCP adds latency through its reasoning layer. Direct API calls will provide better performance.</p>
        <p><strong>Next Steps:</strong> Implement direct API integration with proper error handling.</p>
      </div>
    `;
  } else if (step3 === 'enterprise') {
    recommendation = `
      <div class="recommendation-box">
        <h4>Recommendation: Build Custom MCP Server</h4>
        <p>For enterprise-wide deployment, building an internal MCP server creates a reusable tool layer that multiple teams can leverage. The ROI is Very High when shared across the organization.</p>
        <p><strong>Estimated Investment:</strong> 400-650 hours</p>
        <p><strong>Next Steps:</strong> Form a cross-functional team and define server requirements.</p>
      </div>
    `;
  } else if (step1 === 'proprietary' || step1 === 'legacy') {
    recommendation = `
      <div class="recommendation-box">
        <h4>Recommendation: Build Custom MCP Server</h4>
        <p>For proprietary or legacy systems, no public MCP servers exist. A custom server will enable AI agents to access these systems securely.</p>
        <p><strong>Estimated Investment:</strong> 160-400 hours</p>
        <p><strong>ROI:</strong> High - Enables new capabilities</p>
      </div>
    `;
  } else if (step2 === 'workflow') {
    recommendation = `
      <div class="recommendation-box">
        <h4>Recommendation: Build Custom MCP Server</h4>
        <p>Custom MCP excels at multi-agent orchestration. You can combine database queries, API calls, and business logic in one conversational interface.</p>
        <p><strong>Estimated Investment:</strong> 240-400 hours</p>
        <p><strong>ROI:</strong> High - 30%+ efficiency gains</p>
      </div>
    `;
  } else {
    recommendation = `
      <div class="recommendation-box">
        <h4>Recommendation: Evaluate Case-by-Case</h4>
        <p>Your scenario has mixed signals. Consider factors like development time, maintenance burden, and expected ROI.</p>
        <p><strong>Next Steps:</strong> Use the Cost Calculator to estimate investment and review similar scenarios in the Decision Framework.</p>
      </div>
    `;
  }
  
  document.getElementById('wizardRecommendation').innerHTML = recommendation;
}