export const DEPTH_OPTIONS = [10, 25, 50];
export const TIMEFRAME_OPTIONS = [
  { value: '7d', label: 'Last 7 Days' },
  { value: '30d', label: 'Last 30 Days' },
  { value: 'all', label: 'All Time' },
];