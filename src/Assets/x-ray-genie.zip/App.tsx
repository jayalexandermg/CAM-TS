import React, { useState, useCallback } from 'react';
import { AnalysisResult } from './types';
import { generateXrayAnalysis } from './services/geminiService';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import Loader from './components/Loader';
import ResultsDashboard from './components/ResultsDashboard';
import ValueProposition from './components/ValueProposition';
import HowItWorks from './components/HowItWorks';
import Features from './components/Features';
import SocialProof from './components/SocialProof';
import Integrations from './components/Integrations';
import FAQ from './components/FAQ';
import Pricing from './components/Pricing';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

const ParticleBackground: React.FC = () => (
  <div className="fixed top-0 left-0 w-full h-full -z-10 overflow-hidden">
    {Array.from({ length: 50 }).map((_, i) => {
      const size = Math.random() * 3 + 1;
      const style = {
        width: `${size}px`,
        height: `${size}px`,
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        animationDelay: `${Math.random() * 25}s`,
        animationDuration: `${20 + Math.random() * 15}s`,
      };
      return <div key={i} className="particle" style={style} />;
    })}
  </div>
);

const LandingPage: React.FC<{ onAnalysis: (query: string, depth: number, timeframe: string) => void; error: string | null; }> = ({ onAnalysis, error }) => (
    <>
        <HeroSection onAnalysis={onAnalysis} error={error} />
        <main>
          <ValueProposition />
          <HowItWorks />
          <Features />
          <SocialProof />
          <Integrations />
          <FAQ />
          <Pricing />
          <FinalCTA />
        </main>
        <Footer />
    </>
);


const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalysis = useCallback(async (query: string, depth: number, timeframe: string) => {
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    try {
      const result = await generateXrayAnalysis(query, depth, timeframe);
      setAnalysisResult(result);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const handleReset = useCallback(() => {
    setAnalysisResult(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div className="min-h-screen text-gray-200 selection:bg-cyan-300 selection:text-cyan-900">
      <ParticleBackground />
      <Header onNewAnalysis={handleReset} hasResults={!!analysisResult} />
      
        {isLoading && (
            <main className="flex items-center justify-center py-32">
                <Loader />
            </main>
        )}
        {!isLoading && analysisResult && (
            <main className="py-16">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <ResultsDashboard result={analysisResult} />
              </div>
            </main>
        )}
        {!isLoading && !analysisResult && (
            <LandingPage onAnalysis={handleAnalysis} error={error} />
        )}
    </div>
  );
};

export default App;