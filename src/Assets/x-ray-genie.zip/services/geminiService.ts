import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    topTweets: {
      type: Type.ARRAY,
      description: "A list of the top tweets found, ranked by engagement.",
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING, description: "A unique fictional tweet ID." },
          author: { type: Type.STRING, description: "The author's display name." },
          handle: { type: Type.STRING, description: "The author's Twitter handle (e.g., '@handle')." },
          avatarUrl: { type: Type.STRING, description: "URL to the author's avatar image from picsum.photos." },
          text: { type: Type.STRING, description: "The full text content of the tweet, including hashtags." },
          engagement: {
            type: Type.OBJECT,
            properties: {
              likes: { type: Type.INTEGER, description: "Number of likes." },
              retweets: { type: Type.INTEGER, description: "Number of retweets." },
              replies: { type: Type.INTEGER, description: "Number of replies." },
              bookmarks: { type: Type.INTEGER, description: "Number of bookmarks." },
            },
            required: ['likes', 'retweets', 'replies', 'bookmarks']
          },
          isThread: { type: Type.BOOLEAN, description: "Whether the tweet is part of a thread." },
          threadContent: {
            type: Type.ARRAY,
            description: "An array of strings, each representing a subsequent tweet in the thread. Only present if isThread is true.",
            items: { type: Type.STRING }
          }
        },
        required: ['id', 'author', 'handle', 'avatarUrl', 'text', 'engagement', 'isThread']
      },
    },
    formatBreakdown: {
      type: Type.OBJECT,
      properties: {
        commonHooks: { type: Type.ARRAY, items: { type: Type.STRING }, description: "3 examples of effective hooks found." },
        commonBodyStyles: { type: Type.ARRAY, items: { type: Type.STRING }, description: "3 common formatting styles observed (e.g., 'Bulleted lists', 'Short paragraphs')." },
        commonCTAs: { type: Type.ARRAY, items: { type: Type.STRING }, description: "3 examples of calls to action." },
      },
      required: ['commonHooks', 'commonBodyStyles', 'commonCTAs']
    },
    archetypeAnalysis: {
      type: Type.ARRAY,
      description: "A breakdown of content archetypes. The percentages must sum to 100.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "The name of the archetype (e.g., 'Storytelling', 'Listicle', 'Advice', 'Meme/Image')." },
          percentage: { type: Type.INTEGER, description: "The percentage of content that fits this archetype." },
        },
        required: ['name', 'percentage']
      },
    },
  },
  required: ['topTweets', 'formatBreakdown', 'archetypeAnalysis']
};


export const generateXrayAnalysis = async (query: string, depth: number, timeframe: string): Promise<AnalysisResult> => {
  const timeframeLabel = timeframe === '7d' ? '7 days' : timeframe === '30d' ? '30 days' : 'all time';

  const prompt = `
    You are X-ray Genie, an expert AI Twitter analyst. Your task is to simulate the scraping and analysis of a Twitter account, keyword, or URL.
    Based on the user's query: "${query}", generate a detailed analysis for the top ${depth} tweets within the last "${timeframeLabel}".
    The output MUST be a single, valid JSON object that strictly adheres to the provided schema.
    Do not include any introductory text, markdown formatting, or anything else outside of the JSON object.

    Generate realistic but fictional data. For example, for a query about '@reactjs', create tweets about React features, hooks, and community news.
    Ensure engagement numbers are plausible for the query.
    The 'avatarUrl' should be a placeholder image URL from picsum.photos, like 'https://picsum.photos/100/100'.
    The 'archetypeAnalysis' percentages must sum to 100.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: analysisSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as AnalysisResult;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to generate analysis. The model may be unable to produce a valid response for the given query.");
  }
};
