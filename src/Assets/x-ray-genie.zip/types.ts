export interface EngagementMetrics {
  likes: number;
  retweets: number;
  replies: number;
  bookmarks: number;
}

export interface Tweet {
  id: string;
  author: string;
  handle: string;
  avatarUrl: string;
  text: string;
  engagement: EngagementMetrics;
  isThread: boolean;
  threadContent?: string[];
}

export interface FormatBreakdown {
  commonHooks: string[];
  commonBodyStyles: string[];
  commonCTAs: string[];
}

export interface Archetype {
  name: string;
  percentage: number;
}

export interface AnalysisResult {
  topTweets: Tweet[];
  formatBreakdown: FormatBreakdown;
  archetypeAnalysis: Archetype[];
}