import React from 'react';
import { AnalysisResult } from '../types';
import TweetCard from './TweetCard';
import InsightsPanel from './InsightsPanel';

interface ResultsDashboardProps {
  result: AnalysisResult;
}

const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ result }) => {

  const exportToCSV = () => {
    const headers = ['Author', 'Handle', 'Text', 'Likes', 'Retweets', 'Replies', 'Bookmarks'];
    const rows = result.topTweets.map(tweet => [
      `"${tweet.author}"`,
      `"${tweet.handle}"`,
      `"${tweet.text.replace(/"/g, '""')}"`,
      tweet.engagement.likes,
      tweet.engagement.retweets,
      tweet.engagement.replies,
      tweet.engagement.bookmarks
    ].join(','));

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "x-ray-genie-export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold">Analysis Results</h2>
          <div className="flex space-x-2">
            <button className="px-4 py-2 text-sm font-semibold bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">Add to Library</button>
            <button onClick={exportToCSV} className="px-4 py-2 text-sm font-semibold bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg transition-colors">Export Insights</button>
          </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-xl font-semibold text-gray-300">Top Tweets</h3>
          {result.topTweets.map(tweet => (
            <TweetCard key={tweet.id} tweet={tweet} />
          ))}
        </div>
        <div className="lg:col-span-1">
           <InsightsPanel result={result} />
        </div>
      </div>
    </div>
  );
};

export default ResultsDashboard;
