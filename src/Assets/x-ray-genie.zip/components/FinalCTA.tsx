import React from 'react';
import SectionWrapper from './SectionWrapper';

const FinalCTA: React.FC = () => {
    return (
        <SectionWrapper className="!py-20">
             <div className="relative text-center bg-gradient-to-br from-purple-600/20 to-cyan-500/20 rounded-2xl p-12 overflow-hidden">
                 <div className="absolute -inset-12 bg-grid-pattern opacity-10 [mask-image:radial-gradient(ellipse_at_center,white,transparent_70%)]"></div>
                 <style>{`
                    .bg-grid-pattern {
                        background-image: linear-gradient(white .5px, transparent .5px), linear-gradient(90deg, white .5px, transparent .5px);
                        background-size: 20px 20px;
                    }
                 `}</style>
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk text-white">
                    See Twitter Like Never Before
                </h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-300">
                    Start your free trial and uncover insights hiding in plain sight.
                </p>
                <div className="mt-8">
                     <div className="inline-block p-0.5 bg-gradient-to-r from-cyan-400 via-purple-500 to-fuchsia-500 rounded-full animate-[animated-gradient_4s_ease_infinite] bg-[length:200%_auto]">
                        <button 
                            className="w-full h-12 px-8 font-bold bg-[#1d2333] text-white rounded-full transition-all duration-300
                                       hover:bg-transparent hover:text-white"
                        >
                            Start Free Trial
                        </button>
                    </div>
                </div>
            </div>
        </SectionWrapper>
    );
};

export default FinalCTA;
