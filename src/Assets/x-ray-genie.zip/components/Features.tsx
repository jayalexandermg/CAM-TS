import React from 'react';
import SectionWrapper from './SectionWrapper';
import { UsersIcon, HashIcon, ActivityIcon, ClockIcon, DownloadIcon, ZapIcon } from './icons';

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string; }> = ({ icon, title, description }) => (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-6 transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 hover:border-cyan-400/50">
        <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-purple-600 mb-4">
            {icon}
        </div>
        <h3 className="text-xl font-bold font-space-grotesk">{title}</h3>
        <p className="mt-2 text-gray-400">{description}</p>
    </div>
);


const Features: React.FC = () => {
    const features = [
        { icon: <UsersIcon className="w-6 h-6 text-white" />, title: "Influencer Mapping", description: "Find who drives conversations and identify key voices in any niche." },
        { icon: <HashIcon className="w-6 h-6 text-white" />, title: "Hashtag Trends", description: "Uncover fast-moving patterns and jump on trending topics before they peak." },
        { icon: <ActivityIcon className="w-6 h-6 text-white" />, title: "Engagement Analytics", description: "See what content formats, hooks, and CTAs actually resonate with audiences." },
        { icon: <ClockIcon className="w-6 h-6 text-white" />, title: "Historical Search", description: "Look back 7, 30, 90 days, or All-Time to understand long-term trends." },
        { icon: <ZapIcon className="w-6 h-6 text-white" />, title: "AI-Powered Insights", description: "Go beyond raw data with AI-driven analysis of content archetypes and formats." },
        { icon: <DownloadIcon className="w-6 h-6 text-white" />, title: "Export & Share", description: "Get insights out to your team fast with simple CSV and PDF exports." }
    ];

    return (
        <SectionWrapper>
            <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
                  A Powerful <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">Analysis Engine</span>
                </h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
                    Everything you need to turn Twitter's noise into actionable signals.
                </p>
            </div>
            <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {features.map(feature => <FeatureCard key={feature.title} {...feature} />)}
            </div>
        </SectionWrapper>
    );
};

export default Features;
