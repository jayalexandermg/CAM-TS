import React from 'react';
import SectionWrapper from './SectionWrapper';
import { SearchIcon, BarChartIcon, ZapIcon } from './icons';

const StepCard: React.FC<{ icon: React.ReactNode; title: string; description: string; step: number; }> = ({ icon, title, description, step }) => (
    <div className="relative text-center">
        <div className="absolute -top-4 -right-4 w-12 h-12 flex items-center justify-center bg-cyan-500/10 text-cyan-300 font-bold rounded-full border-2 border-cyan-400/30 font-space-grotesk text-xl">{step}</div>
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-8 flex flex-col items-center h-full">
            <div className="w-16 h-16 flex items-center justify-center rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 mb-4">
                {icon}
            </div>
            <h3 className="text-2xl font-bold font-space-grotesk">{title}</h3>
            <p className="mt-2 text-gray-400">{description}</p>
        </div>
    </div>
);

const HowItWorks: React.FC = () => {
    return (
        <SectionWrapper className="bg-black/20">
             <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">How It Works</h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
                    Get from query to insight in three simple steps.
                </p>
            </div>
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 relative">
                <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent hidden md:block -translate-y-1/2" />
                 <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-500/30 to-transparent hidden md:block -translate-y-1/2 blur-lg" />

                <StepCard step={1} icon={<SearchIcon className="w-8 h-8 text-white"/>} title="Search" description="Enter any handle, keyword, or tweet URL to start your analysis." />
                <StepCard step={2} icon={<BarChartIcon className="w-8 h-8 text-white"/>} title="Analyze" description="Our AI uncovers top tweets, content themes, and engagement patterns." />
                <StepCard step={3} icon={<ZapIcon className="w-8 h-8 text-white"/>} title="Unlock Insights" description="Export, share, and act on data-driven insights to grow your audience." />
            </div>
        </SectionWrapper>
    );
};

export default HowItWorks;
