import React from 'react';
import SectionWrapper from './SectionWrapper';
import { XCircle, CheckCircle } from './icons';

const ValueCard: React.FC<{ title: string; items: string[]; isPositive?: boolean }> = ({ title, items, isPositive = false }) => (
  <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 h-full transform hover:-translate-y-1 transition-transform duration-300">
    <h3 className={`text-2xl font-bold font-space-grotesk ${isPositive ? 'text-cyan-400' : 'text-gray-400'}`}>{title}</h3>
    <ul className="mt-4 space-y-3">
      {items.map((item, index) => (
        <li key={index} className="flex items-start">
          {isPositive ? <CheckCircle className="w-5 h-5 text-green-400 mr-3 mt-1 flex-shrink-0" /> : <XCircle className="w-5 h-5 text-red-400 mr-3 mt-1 flex-shrink-0" />}
          <span className="text-gray-300">{item}</span>
        </li>
      ))}
    </ul>
  </div>
);

const ValueProposition: React.FC = () => {
  const withoutItems = [
    'Endless scrolling for content ideas',
    'Guessing which formats perform best',
    'Missing emerging trends and hashtags',
    'Manually tracking competitor content'
  ];

  const withItems = [
    'Instant insights on top-performing content',
    'Data-driven format & archetype analysis',
    'Real-time opportunity spotting',
    'Automated analysis of any account or keyword'
  ];

  return (
    <SectionWrapper>
      <div className="text-center">
        <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
          Stop Guessing. <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">Start Seeing.</span>
        </h2>
        <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-400">
          Turn Twitter into a source of intelligence — instantly uncover content patterns, influencers, and hidden opportunities.
        </p>
      </div>
      <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
        <ValueCard title="Without X-ray Genie..." items={withoutItems} />
        <ValueCard title="With X-ray Genie" items={withItems} isPositive />
      </div>
    </SectionWrapper>
  );
};

export default ValueProposition;
