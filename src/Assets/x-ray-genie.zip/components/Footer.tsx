import React from 'react';

const Footer: React.FC = () => {
    const links = ['Library', 'Analytics', 'Pricing', 'Docs', 'Status'];
    return (
        <footer className="border-t border-white/10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex flex-col sm:flex-row justify-between items-center">
                    <div className="flex items-center space-x-2">
                         <span className="text-xl">🔮</span>
                        <span className="font-bold text-lg font-space-grotesk">X-ray Genie</span>
                    </div>
                    <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 mt-4 sm:mt-0">
                        {links.map(link => (
                            <a key={link} href="#" className="text-sm text-gray-400 hover:text-white transition-colors">{link}</a>
                        ))}
                    </nav>
                </div>
                <div className="mt-6 text-center text-sm text-gray-500">
                    <p>&copy; {new Date().getFullYear()} Genie Labs, Inc. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
