import React from 'react';
import SectionWrapper from './SectionWrapper';

const IntegrationIcon: React.FC<{ name: string }> = ({ name }) => (
    <div className="w-20 h-20 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center transition-all duration-300 hover:bg-white/10 hover:border-cyan-400/50 hover:scale-110">
        <span className="font-medium text-lg">{name}</span>
    </div>
);

const Integrations: React.FC = () => {
    const tools = ["Slack", "Notion", "Sheets", "Zapier"];

    return (
        <SectionWrapper>
            <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
                    Works With the Tools You Use
                </h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
                    Seamlessly connect X-ray Genie to your team's workflow and turn insights into action faster.
                </p>
            </div>
            <div className="mt-12 flex justify-center items-center gap-6 md:gap-8">
                {tools.map(tool => <IntegrationIcon key={tool} name={tool} />)}
            </div>
        </SectionWrapper>
    );
};

export default Integrations;
