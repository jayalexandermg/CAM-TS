import React from 'react';
import SectionWrapper from './SectionWrapper';

const TestimonialCard: React.FC<{ text: string; author: string; company: string; imageUrl: string }> = ({ text, author, company, imageUrl }) => (
    <figure className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-8 h-full flex flex-col">
        <blockquote className="text-gray-300 flex-grow">“{text}”</blockquote>
        <figcaption className="flex items-center mt-6">
            <img className="w-12 h-12 rounded-full" src={imageUrl} alt={author} />
            <div className="ml-4">
                <div className="font-bold text-white">{author}</div>
                <div className="text-gray-400">{company}</div>
            </div>
        </figcaption>
    </figure>
);

const SocialProof: React.FC = () => {
    const testimonials = [
        { text: "Finally a tool that makes sense of Twitter chaos. The insights are incredibly sharp and actionable.", author: "Sarah Jones", company: "Founder, Growth Co.", imageUrl: "https://i.pravatar.cc/150?u=a042581f4e29026704d" },
        { text: "X-ray Genie saved me hours of manual scrolling and guesswork every single week. It's a game-changer.", author: "Mike Steiner", company: "Content Lead, Future SaaS", imageUrl: "https://i.pravatar.cc/150?u=a042581f4e29026704a" },
        { text: "It's like having X-ray vision for the timeline. We can now spot opportunities and trends before anyone else.", author: "Elena Rodriguez", company: "Marketing Director, V-Corp", imageUrl: "https://i.pravatar.cc/150?u=a042581f4e29026704b" }
    ];

    const logos = ["Stripe", "Linear", "Vercel", "Notion", "Figma"];

    return (
        <SectionWrapper className="bg-black/20">
            <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
                    Trusted by Modern Teams
                </h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
                    See why leading creators and marketers use X-ray Genie to stay ahead.
                </p>
            </div>
            <div className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-8">
                {testimonials.map((t, i) => <TestimonialCard key={i} {...t} />)}
            </div>
             <div className="mt-20">
                <p className="text-center text-gray-400 text-sm font-bold uppercase tracking-widest">POWERING INSIGHTS AT COMPANIES LIKE</p>
                <div className="mt-8 flex justify-center items-center gap-x-8 md:gap-x-12 opacity-40 grayscale">
                    {logos.map(logo => (
                        <div key={logo} className="text-2xl font-bold">{logo}</div>
                    ))}
                </div>
            </div>
        </SectionWrapper>
    );
};

export default SocialProof;
