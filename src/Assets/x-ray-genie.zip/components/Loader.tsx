import React, { useState, useEffect } from 'react';

const loadingTexts = [
  "Scanning tweets...",
  "Detecting threads...",
  "Mapping insights...",
  "Analyzing engagement...",
  "Identifying archetypes...",
  "Finalizing report..."
];

const Loader: React.FC = () => {
  const [currentTextIndex, setCurrentTextIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTextIndex((prevIndex) => (prevIndex + 1) % loadingTexts.length);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center text-center">
      <div className="relative w-64 h-48 overflow-hidden">
        <div className="absolute inset-0 grid grid-cols-10 grid-rows-10 gap-px">
          {Array.from({ length: 100 }).map((_, i) => (
            <div key={i} className="bg-cyan-500/10 animate-pulse" style={{ animationDelay: `${Math.random() * 1}s` }} />
          ))}
        </div>
        <div 
          className="absolute top-0 left-0 w-full h-1 bg-cyan-400 shadow-[0_0_15px_2px_rgba(0,255,255,0.7)]"
          style={{ animation: 'scan 4s cubic-bezier(0.4, 0, 0.2, 1) infinite' }}
        />
        <style>{`
          @keyframes scan {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(12rem); }
          }
        `}</style>
      </div>
      <p className="mt-4 text-lg text-cyan-300 font-medium tracking-wider">
        {loadingTexts[currentTextIndex]}
      </p>
    </div>
  );
};

export default Loader;
