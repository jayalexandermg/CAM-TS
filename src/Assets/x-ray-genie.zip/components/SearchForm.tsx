import React, { useState } from 'react';
import { DEPTH_OPTIONS, TIMEFRAME_OPTIONS } from '../constants';

interface SearchFormProps {
  onAnalysis: (query: string, depth: number, timeframe: string) => void;
  error: string | null;
}

const SearchForm: React.FC<SearchFormProps> = ({ onAnalysis, error }) => {
  const [query, setQuery] = useState('');
  const [depth, setDepth] = useState<number>(DEPTH_OPTIONS[1]); // Default to 25
  const [timeframe, setTimeframe] = useState<string>(TIMEFRAME_OPTIONS[1].value); // Default to 30d

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onAnalysis(query, depth, timeframe);
    }
  };

  return (
    <div 
      className="max-w-3xl mx-auto flex flex-col items-center text-center"
      style={{ animation: 'fade-in-up 0.8s 0.2s ease-out forwards', opacity: 0 }}
    >
      <h2 
        className="text-5xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-fuchsia-500 font-space-grotesk bg-[length:200%_auto]"
        style={{ animation: 'gradient-sweep 2s ease-out forwards' }}
      >
        Unlock Twitter Insights
      </h2>
      <p className="mt-4 text-xl text-gray-400 tracking-wider">
        Enter any X handle, keyword, or tweet URL to uncover top content, patterns, and opportunities.
      </p>

      <div className="relative w-full mt-12">
        <div 
          className="absolute -inset-3 bg-gradient-to-r from-cyan-500 via-purple-600 to-fuchsia-500 rounded-2xl blur-2xl opacity-40 animate-[animated-gradient_6s_ease_infinite] bg-[length:200%_auto]"
          aria-hidden="true"
        ></div>
        <div className="relative w-full p-6 bg-white/5 backdrop-blur-lg rounded-2xl shadow-2xl shadow-black/40 border border-white/10">
          <form onSubmit={handleSubmit}>
            <div className="relative flex items-center group">
              <div 
                className="absolute -inset-px bg-gradient-to-r from-cyan-500 to-purple-500 rounded-lg opacity-0 group-focus-within:opacity-100 transition-opacity duration-300"
                style={{ animation: 'focus-pulse 2s infinite ease-out' }}
              />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="e.g., @naval, #buildinpublic, or a tweet URL"
                className="relative w-full h-14 pl-5 pr-48 text-lg bg-gray-900/80 border border-transparent focus:border-transparent rounded-lg focus:outline-none transition-all duration-300 placeholder:text-gray-500"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 bg-gradient-to-r from-cyan-400 via-purple-500 to-fuchsia-500 rounded-full animate-[animated-gradient_4s_ease_infinite] bg-[length:200%_auto]">
                <button 
                  type="submit" 
                  className="w-full h-10 px-6 font-bold bg-[#1d2333] text-white rounded-full transition-all duration-300
                             hover:bg-transparent hover:text-white
                             focus:outline-none"
                >
                  X-ray It 🔮
                </button>
              </div>
            </div>
          </form>
          
          {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

          <div className="mt-6 flex flex-col sm:flex-row justify-center items-center gap-x-8 gap-y-4">
            <div className="flex items-center space-x-3">
              <span className="text-sm font-medium text-gray-400">Depth:</span>
              {DEPTH_OPTIONS.map(d => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDepth(d)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300 transform hover:scale-110 ${depth === d 
                    ? 'bg-white/10 text-cyan-300 shadow-[0_4px_15px_-5px_rgba(56,189,248,0.7)]' 
                    : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-gray-200'}`}
                >
                  Top {d}
                </button>
              ))}
            </div>
            <div className="flex items-center space-x-3">
               <span className="text-sm font-medium text-gray-400">Time:</span>
              {TIMEFRAME_OPTIONS.map(t => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setTimeframe(t.value)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300 transform hover:scale-110 ${timeframe === t.value 
                    ? 'bg-white/10 text-cyan-300 shadow-[0_4px_15px_-5px_rgba(56,189,248,0.7)]'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-gray-200'}`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchForm;
