import React from 'react';
import { Tweet } from '../types';
import { HeartIcon, RepeatIcon, MessageSquareIcon, BookmarkIcon, ChevronsDown } from './icons';

interface TweetCardProps {
  tweet: Tweet;
}

const TweetCard: React.FC<TweetCardProps> = ({ tweet }) => {
  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num;
  };
  
  return (
    <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/60 rounded-lg p-5 transition-all duration-300 hover:border-cyan-500/50 hover:shadow-2xl hover:shadow-black/40 hover:-translate-y-1">
      <div className="flex items-start space-x-4">
        <img src={tweet.avatarUrl} alt={tweet.author} className="w-12 h-12 rounded-full" />
        <div className="flex-1">
          <div className="flex items-baseline space-x-2">
            <span className="font-bold text-white">{tweet.author}</span>
            <span className="text-sm text-gray-400">{tweet.handle}</span>
          </div>
          <p className="mt-2 text-gray-200 whitespace-pre-wrap">{tweet.text}</p>

          {tweet.isThread && tweet.threadContent && (
             <div className="mt-3 border-l-2 border-gray-700 pl-4 space-y-3">
              <div className="flex items-center text-sm text-cyan-400">
                <ChevronsDown className="w-4 h-4 mr-2"/>
                <span>Full Thread</span>
              </div>
               {tweet.threadContent.map((content, index) => (
                 <p key={index} className="text-gray-300 whitespace-pre-wrap text-sm">{content}</p>
               ))}
             </div>
          )}

          <div className="mt-4 flex items-center justify-between text-gray-400 max-w-sm">
            <div className="flex items-center space-x-1 hover:text-red-500 transition-colors">
              <HeartIcon className="w-5 h-5" />
              <span className="text-sm">{formatNumber(tweet.engagement.likes)}</span>
            </div>
            <div className="flex items-center space-x-1 hover:text-green-500 transition-colors">
              <RepeatIcon className="w-5 h-5" />
              <span className="text-sm">{formatNumber(tweet.engagement.retweets)}</span>
            </div>
            <div className="flex items-center space-x-1 hover:text-blue-500 transition-colors">
              <MessageSquareIcon className="w-5 h-5" />
              <span className="text-sm">{formatNumber(tweet.engagement.replies)}</span>
            </div>
             <div className="flex items-center space-x-1 hover:text-yellow-500 transition-colors">
              <BookmarkIcon className="w-5 h-5" />
              <span className="text-sm">{formatNumber(tweet.engagement.bookmarks)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TweetCard;
