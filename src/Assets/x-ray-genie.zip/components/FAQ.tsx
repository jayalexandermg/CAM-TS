import React, { useState } from 'react';
import SectionWrapper from './SectionWrapper';
import { ChevronDown } from './icons';

const FaqItem: React.FC<{ question: string; children: React.ReactNode }> = ({ question, children }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border-b border-white/10">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center text-left py-6"
            >
                <span className="text-lg font-medium text-gray-100">{question}</span>
                <ChevronDown className={`w-6 h-6 text-cyan-400 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                <div className="pb-6 text-gray-400 leading-relaxed">
                    {children}
                </div>
            </div>
        </div>
    );
};


const FAQ: React.FC = () => {
    return (
        <SectionWrapper className="bg-black/20">
             <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
                    Frequently Asked Questions
                </h2>
            </div>
            <div className="mt-12 max-w-3xl mx-auto">
                <FaqItem question="How accurate is the data?">
                    Our data is simulated for demonstration purposes but is designed to reflect realistic engagement patterns and content types you would find on X (Twitter). The AI generates plausible data based on the query provided.
                </FaqItem>
                <FaqItem question="Can I search historical tweets?">
                    Yes, you can filter your analysis by the last 7 days, 30 days, or "All Time" to get a broad historical perspective on the content's performance.
                </FaqItem>
                <FaqItem question="Does it support multiple languages?">
                    Currently, X-ray Genie is optimized for English-language content analysis. Support for additional languages is on our future roadmap.
                </FaqItem>
                <FaqItem question="Can I export the results?">
                    Absolutely! You can export the list of top tweets, along with their engagement metrics, to a CSV file with a single click from the results dashboard.
                </FaqItem>
            </div>
        </SectionWrapper>
    );
};

export default FAQ;
