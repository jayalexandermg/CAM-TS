import React, { useState } from 'react';
import SectionWrapper from './SectionWrapper';
import { CheckCircle } from './icons';

interface PricingTierProps {
    plan: string;
    price: string;
    description: string;
    features: string[];
    isPopular?: boolean;
    isYearly: boolean;
}

const PricingTier: React.FC<PricingTierProps> = ({ plan, price, description, features, isPopular = false, isYearly }) => (
    <div className={`relative bg-white/5 border ${isPopular ? 'border-purple-500' : 'border-white/10'} rounded-2xl p-8 transform hover:-translate-y-2 transition-transform duration-300`}>
        {isPopular && (
            <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2 px-4 py-1 text-sm font-bold text-white bg-gradient-to-r from-purple-600 to-fuchsia-500 rounded-full">
                Most Popular
            </div>
        )}
        <h3 className="text-2xl font-bold font-space-grotesk">{plan}</h3>
        <p className="mt-2 text-gray-400">{description}</p>
        <div className="mt-6">
            <span className="text-5xl font-bold">${price}</span>
            <span className="text-gray-400">/mo</span>
        </div>
        <button className={`w-full mt-6 py-3 rounded-lg font-bold transition-colors ${isPopular ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white hover:opacity-90' : 'bg-white/10 hover:bg-white/20'}`}>
            Get Started
        </button>
        <ul className="mt-8 space-y-3 text-gray-300">
            {features.map((feature, i) => (
                <li key={i} className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                    <span>{feature}</span>
                </li>
            ))}
        </ul>
    </div>
);


const Pricing: React.FC = () => {
    const [isYearly, setIsYearly] = useState(false);
    
    const tiers = [
        { plan: 'Starter', price: isYearly ? 24 : 29, description: 'For individuals & creators getting started.', features: ['100 searches/mo', 'Top 25 results', 'Basic analytics', 'CSV Export'] },
        { plan: 'Pro', price: isYearly ? 83 : 99, description: 'For professionals & small teams.', features: ['Unlimited searches', 'Top 50 results', 'Advanced insights', 'CSV & PDF Exports', 'Priority support'], isPopular: true },
        { plan: 'Business', price: isYearly ? 208 : 249, description: 'For agencies and large teams.', features: ['Everything in Pro', 'API Access', 'Team Seats', 'Dedicated support'] }
    ];

    return (
        <SectionWrapper>
            <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
                    Find the Perfect Plan
                </h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
                    Start for free, then upgrade to unlock powerful features.
                </p>
            </div>

            <div className="mt-8 flex justify-center items-center space-x-4">
                <span className={`font-medium ${!isYearly ? 'text-white' : 'text-gray-500'}`}>Monthly</span>
                <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" checked={isYearly} onChange={() => setIsYearly(!isYearly)} className="sr-only peer" />
                    <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-600"></div>
                </label>
                <span className={`font-medium ${isYearly ? 'text-white' : 'text-gray-500'}`}>
                    Yearly <span className="text-cyan-400">(Save 15%)</span>
                </span>
            </div>

            <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
                {tiers.map(tier => <PricingTier key={tier.plan} {...tier} price={String(tier.price)} isYearly={isYearly} />)}
            </div>
        </SectionWrapper>
    );
};

export default Pricing;
