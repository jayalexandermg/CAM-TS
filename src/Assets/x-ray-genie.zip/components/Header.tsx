import React from 'react';

interface HeaderProps {
    onNewAnalysis: () => void;
    hasResults: boolean;
}

const Header: React.FC<HeaderProps> = ({ onNewAnalysis, hasResults }) => {
  return (
    <header className="bg-black/10 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div 
                className="absolute -inset-1.5 rounded-full" 
                style={{ animation: 'emoji-pulse 4s ease-in-out infinite' }}
              />
              <span className="text-2xl relative">🔮</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-fuchsia-500 font-space-grotesk">
              X-ray Genie
            </h1>
          </div>
          <nav className="flex items-center space-x-4">
              {hasResults && (
                <button 
                  onClick={onNewAnalysis}
                  className="text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  + New Analysis
                </button>
              )}
            <a href="#" className="text-sm text-gray-400 hover:text-white transition-colors hidden md:block">Library</a>
            <a href="#" className="text-sm text-gray-400 hover:text-white transition-colors hidden md:block">Analytics</a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;