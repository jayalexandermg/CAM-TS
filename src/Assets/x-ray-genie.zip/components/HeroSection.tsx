import React from 'react';
import SearchForm from './SearchForm';

interface HeroSectionProps {
    onAnalysis: (query: string, depth: number, timeframe: string) => void;
    error: string | null;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onAnalysis, error }) => {
    return (
        <section className="relative overflow-hidden py-20 md:py-32">
             <div 
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60rem] h-[60rem] rounded-full bg-gradient-to-tr from-purple-600/20 via-cyan-500/10 to-transparent blur-3xl opacity-50"
                style={{ animation: 'aurora 15s ease-in-out infinite alternate' }}
                aria-hidden="true"
            />
            <div className="relative px-4 sm:px-6 lg:px-8">
                <SearchForm onAnalysis={onAnalysis} error={error} />
            </div>
        </section>
    );
};

export default HeroSection;
