import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { Archetype } from '../types';

interface ArchetypeRadarChartProps {
  data: Archetype[];
}

const ArchetypeRadarChart: React.FC<ArchetypeRadarChartProps> = ({ data }) => {
  const chartData = data.map(item => ({
    subject: item.name,
    A: item.percentage,
    fullMark: 100
  }));

  return (
    <ResponsiveContainer width="100%" height="100%">
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
        <defs>
          <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
            <stop offset="95%" stopColor="#8884d8" stopOpacity={0.2}/>
          </linearGradient>
        </defs>
        <PolarGrid stroke="#4A5568" />
        <PolarAngleAxis dataKey="subject" tick={{ fill: '#A0AEC0', fontSize: 12 }} />
        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#718096', fontSize: 10 }} />
        <Radar name="Percentage" dataKey="A" stroke="#38BDF8" fill="url(#colorUv)" fillOpacity={0.6} />
        <Tooltip
          contentStyle={{
            backgroundColor: 'rgba(23, 25, 35, 0.8)',
            borderColor: '#4A5568',
            borderRadius: '0.5rem',
          }}
          labelStyle={{ color: '#E2E8F0' }}
          formatter={(value: number) => [`${value}%`, 'Prevalence']}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
};

export default ArchetypeRadarChart;
