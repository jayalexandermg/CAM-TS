import React from 'react';
import { AnalysisResult } from '../types';
import ArchetypeRadarChart from './ArchetypeRadarChart';

interface InsightsPanelProps {
  result: AnalysisResult;
}

const InsightSection: React.FC<{title: string; items: string[]}> = ({ title, items }) => (
    <div>
        <h4 className="font-semibold text-gray-200">{title}</h4>
        <ul className="mt-2 space-y-2 text-sm text-gray-400">
            {items.map((item, index) => (
                <li key={index} className="relative pl-4 before:content-['-'] before:absolute before:left-0 before:text-cyan-400">
                   {`"${item}"`}
                </li>
            ))}
        </ul>
    </div>
);


const InsightsPanel: React.FC<InsightsPanelProps> = ({ result }) => {
  return (
    <div className="sticky top-24 space-y-6">
      <div className="p-5 bg-gray-800/50 backdrop-blur-md border border-gray-700/60 rounded-lg">
        <h3 className="text-xl font-semibold text-gray-200 mb-4">Content Archetypes</h3>
        <div className="w-full h-64">
          <ArchetypeRadarChart data={result.archetypeAnalysis} />
        </div>
      </div>
      <div className="p-5 bg-gray-800/50 backdrop-blur-md border border-gray-700/60 rounded-lg">
        <h3 className="text-xl font-semibold text-gray-200 mb-4">Format Breakdown</h3>
        <div className="space-y-4">
            <InsightSection title="Common Hooks" items={result.formatBreakdown.commonHooks} />
            <InsightSection title="Common Body Styles" items={result.formatBreakdown.commonBodyStyles} />
            <InsightSection title="Common CTAs" items={result.formatBreakdown.commonCTAs} />
        </div>
      </div>
    </div>
  );
};

export default InsightsPanel;
